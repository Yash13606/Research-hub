import { pgTable, text, serial, integer, boolean, timestamp, varchar, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Paper Schema
export const papers = pgTable("papers", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  authors: text("authors").notNull(),
  abstract: text("abstract").notNull(),
  publicationDate: timestamp("publication_date").notNull(),
  source: text("source").notNull(),
  sourceId: text("source_id").notNull(),
  url: text("url").notNull(),
  categories: text("categories").array().notNull(),
  citations: integer("citations").default(0),
});

export const insertPaperSchema = createInsertSchema(papers).omit({
  id: true
});

// Summary Schema
export const summaries = pgTable("summaries", {
  id: serial("id").primaryKey(),
  paperId: integer("paper_id").notNull(),
  briefSummary: text("brief_summary"),
  detailedSummary: text("detailed_summary"),
  technicalSummary: text("technical_summary"),
  generatedAt: timestamp("generated_at").defaultNow(),
});

export const insertSummarySchema = createInsertSchema(summaries).omit({
  id: true,
  generatedAt: true
});

// Saved Papers Schema
export const savedPapers = pgTable("saved_papers", {
  id: serial("id").primaryKey(),
  paperId: integer("paper_id").notNull(),
  userId: integer("user_id"),
  savedAt: timestamp("saved_at").defaultNow(),
});

export const insertSavedPaperSchema = createInsertSchema(savedPapers).omit({
  id: true,
  savedAt: true
});

// Filter Schema (for tracking user filter preferences)
export const filters = pgTable("filters", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  sources: text("sources").array(),
  categories: text("categories").array(),
  dateRange: text("date_range"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertFilterSchema = createInsertSchema(filters).omit({
  id: true,
  lastUpdated: true
});

// Type Exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Paper = typeof papers.$inferSelect;
export type InsertPaper = z.infer<typeof insertPaperSchema>;

export type Summary = typeof summaries.$inferSelect;
export type InsertSummary = z.infer<typeof insertSummarySchema>;

export type SavedPaper = typeof savedPapers.$inferSelect;
export type InsertSavedPaper = z.infer<typeof insertSavedPaperSchema>;

export type Filter = typeof filters.$inferSelect;
export type InsertFilter = z.infer<typeof insertFilterSchema>;

// API-specific types
export const paperQuerySchema = z.object({
  search: z.string().optional(),
  sources: z.array(z.string()).optional(),
  categories: z.array(z.string()).optional(),
  dateRange: z.string().optional(),
  page: z.number().optional(),
  limit: z.number().optional(),
});

export type PaperQuery = z.infer<typeof paperQuerySchema>;

export const summaryRequestSchema = z.object({
  paperId: z.number(),
  type: z.enum(["brief", "detailed", "technical"]),
});

export type SummaryRequest = z.infer<typeof summaryRequestSchema>;

export const savedPaperRequestSchema = z.object({
  paperId: z.number(),
});

export type SavedPaperRequest = z.infer<typeof savedPaperRequestSchema>;

export default function Footer() {
  return (
    <footer className="bg-white border-t border-neutral-200 py-4">
      <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
        <div className="text-sm text-neutral-500 mb-4 md:mb-0">
          <p>© {new Date().getFullYear()} ResearchPaperHub. All rights reserved.</p>
          <p className="text-xs mt-1">Powered by <a href="https://ai.google.dev/gemini" target="_blank" rel="noreferrer" className="text-primary-600 hover:text-primary-700">Google Gemini API</a></p>
        </div>
        <div className="flex space-x-4">
          <a href="#" className="text-neutral-500 hover:text-neutral-700">Privacy Policy</a>
          <a href="#" className="text-neutral-500 hover:text-neutral-700">Terms of Service</a>
          <a href="#" className="text-neutral-500 hover:text-neutral-700">Contact</a>
        </div>
      </div>
    </footer>
  );
}

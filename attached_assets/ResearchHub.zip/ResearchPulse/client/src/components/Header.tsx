import { useState } from 'react';
import { Search, Settings, Bookmark } from 'lucide-react';
import { debounce } from '@/lib/utils';

interface HeaderProps {
  onSearch: (query: string) => void;
}

export default function Header({ onSearch }: HeaderProps) {
  const [isMobileSearchVisible, setIsMobileSearchVisible] = useState(false);
  
  const handleSearchChange = debounce((e: React.ChangeEvent<HTMLInputElement>) => {
    onSearch(e.target.value);
  }, 500);
  
  const toggleMobileSearch = () => {
    setIsMobileSearchVisible(!isMobileSearchVisible);
  };
  
  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="text-primary-600 text-2xl">📄</div>
          <h1 className="text-xl font-bold text-primary-700">ResearchPaperHub</h1>
        </div>
        
        {/* Desktop search */}
        <div className="hidden md:flex max-w-3xl flex-1 mx-8">
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md leading-5 bg-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="Search papers by title, author, keywords..."
              onChange={handleSearchChange}
            />
          </div>
        </div>
        
        {/* User actions */}
        <div className="flex items-center space-x-3">
          <button className="text-neutral-500 hover:text-neutral-700 p-2 rounded-full hover:bg-neutral-100">
            <Settings className="h-5 w-5" />
          </button>
          <button className="text-neutral-500 hover:text-neutral-700 p-2 rounded-full hover:bg-neutral-100">
            <Bookmark className="h-5 w-5" />
          </button>
          <button 
            className="md:hidden text-neutral-500 hover:text-neutral-700 p-2 rounded-full hover:bg-neutral-100"
            onClick={toggleMobileSearch}
          >
            <Search className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      {/* Mobile search */}
      {isMobileSearchVisible && (
        <div className="md:hidden px-4 pb-3">
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md leading-5 bg-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="Search papers by title, author, keywords..."
              onChange={handleSearchChange}
            />
          </div>
        </div>
      )}
    </header>
  );
}

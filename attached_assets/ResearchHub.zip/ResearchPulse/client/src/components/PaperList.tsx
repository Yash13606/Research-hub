import { useEffect, useState } from 'react';
import PaperCard from './PaperCard';
import { Paper, PapersResponse } from '@/lib/types';
import { useInfiniteQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PaperListProps {
  searchQuery: string;
  filterOptions: {
    sources: string[];
    categories: string[];
    dateRange: string;
  };
  sortOption: string;
}

export default function PaperList({ searchQuery, filterOptions, sortOption }: PaperListProps) {
  const { toast } = useToast();
  const [papers, setPapers] = useState<Paper[]>([]);
  const [totalPapers, setTotalPapers] = useState(0);
  
  // Build query string
  const getQueryString = (pageParam: number) => {
    const params = new URLSearchParams();
    
    if (searchQuery) params.append('search', searchQuery);
    if (filterOptions.sources.length > 0) params.append('sources', filterOptions.sources.join(','));
    if (filterOptions.categories.length > 0) params.append('categories', filterOptions.categories.join(','));
    if (filterOptions.dateRange) params.append('dateRange', filterOptions.dateRange);
    
    params.append('page', pageParam.toString());
    params.append('limit', '10');
    
    return `/api/papers?${params.toString()}`;
  };
  
  // Fetch papers
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    isError,
    refetch
  } = useInfiniteQuery({
    queryKey: ['/api/papers', searchQuery, filterOptions, sortOption],
    queryFn: async ({ pageParam = 1 }) => {
      const response = await fetch(getQueryString(pageParam));
      if (!response.ok) throw new Error('Failed to fetch papers');
      const data = await response.json();
      console.log("Fetched papers:", data); // Debugging log
      return data;
    },
    initialPageParam: 1,
    getNextPageParam: (lastPage, allPages) => {
      const nextPage = allPages.length + 1;
      return lastPage.papers.length < 10 ? undefined : nextPage;
    },
  });
  
  // Update papers when data changes
  useEffect(() => {
    if (data) {
      const allPapers = data.pages.flatMap(page => page.papers);
      setPapers(allPapers);
      
      if (data.pages.length > 0) {
        setTotalPapers(data.pages[0].total);
      }
    }
  }, [data]);
  
  // Refetch when filters change
  useEffect(() => {
    refetch();
  }, [searchQuery, filterOptions, sortOption, refetch]);
  
  // Handle errors
  useEffect(() => {
    if (isError) {
      toast({
        title: "Error",
        description: "Failed to load papers. Please try again.",
        variant: "destructive"
      });
    }
  }, [isError, toast]);
  
  // Sort papers client-side (the API doesn't support sorting yet)
  useEffect(() => {
    if (papers.length > 0) {
      const sortedPapers = [...papers];
      
      switch (sortOption) {
        case 'newest':
          sortedPapers.sort((a, b) => 
            new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime()
          );
          break;
        case 'citations':
          sortedPapers.sort((a, b) => b.citations - a.citations);
          break;
        case 'title':
          sortedPapers.sort((a, b) => a.title.localeCompare(b.title));
          break;
        // 'relevance' is handled by the server when searching
        default:
          break;
      }
      
      setPapers(sortedPapers);
    }
  }, [sortOption, papers.length]);
  
  // Loading state
  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        <div className="flex justify-center items-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
        </div>
      </div>
    );
  }
  
  // No results - this should now be more accurate since we're logging the data
  if (!papers || papers.length === 0) {
    return (
      <div className="p-4 flex flex-col items-center justify-center py-12">
        <div className="text-4xl mb-4">📚</div>
        <h3 className="text-lg font-medium text-neutral-800 mb-2">No papers found</h3>
        <p className="text-neutral-600 text-center max-w-md mb-6">
          We couldn't find any research papers matching your criteria. Try adjusting your filters or search query.
        </p>
        <Button onClick={() => refetch()}>Refresh Results</Button>
      </div>
    );
  }
  
  return (
    <div className="p-4 space-y-4">
      {papers.map((paper) => (
        <PaperCard key={paper.id} paper={paper} />
      ))}
      
      {/* Loading state for next page */}
      {isFetchingNextPage && (
        <div className="flex justify-center items-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
        </div>
      )}
      
      {/* Load more button */}
      {hasNextPage && !isFetchingNextPage && (
        <div className="flex justify-center py-4">
          <Button 
            variant="outline" 
            onClick={() => fetchNextPage()}
            className="px-4 py-2"
          >
            Load More Papers
          </Button>
        </div>
      )}
    </div>
  );
}

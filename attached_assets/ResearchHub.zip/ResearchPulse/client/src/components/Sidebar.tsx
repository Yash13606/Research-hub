import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { FilterOptions, Source, Category } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface SidebarProps {
  onFilterChange: (filters: FilterOptions) => void;
}

export default function Sidebar({ onFilterChange }: SidebarProps) {
  const { toast } = useToast();
  const [sources, setSources] = useState<Source[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedSources, setSelectedSources] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<string>("24h");
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch sources and categories
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sourcesRes, categoriesRes] = await Promise.all([
          fetch('/api/sources'),
          fetch('/api/categories')
        ]);
        
        if (!sourcesRes.ok || !categoriesRes.ok) {
          throw new Error('Failed to fetch filter data');
        }
        
        const sourcesData = await sourcesRes.json();
        const categoriesData = await categoriesRes.json();
        
        setSources(sourcesData);
        setCategories(categoriesData);
        
        // Default to all sources selected
        setSelectedSources(sourcesData.map((source: Source) => source.id));
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching filter data:', error);
        toast({
          title: "Error",
          description: "Failed to load filter options",
          variant: "destructive"
        });
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [toast]);
  
  // Handle source checkbox change
  const handleSourceChange = (sourceId: string, checked: boolean) => {
    setSelectedSources(prev => 
      checked 
        ? [...prev, sourceId] 
        : prev.filter(id => id !== sourceId)
    );
  };
  
  // Handle category checkbox change
  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    setSelectedCategories(prev => 
      checked 
        ? [...prev, categoryId] 
        : prev.filter(id => id !== categoryId)
    );
  };
  
  // Apply filters
  const applyFilters = () => {
    onFilterChange({
      sources: selectedSources,
      categories: selectedCategories,
      dateRange
    });
    
    // On mobile, we might want to close the sidebar
    // This will be handled in the parent component
  };
  
  if (isLoading) {
    return (
      <aside className="hidden md:block w-64 bg-white border-r border-neutral-200 p-4 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-neutral-200 rounded w-1/3"></div>
          <div className="space-y-2">
            <div className="h-4 bg-neutral-200 rounded"></div>
            <div className="h-4 bg-neutral-200 rounded"></div>
            <div className="h-4 bg-neutral-200 rounded"></div>
          </div>
          
          <div className="h-4 bg-neutral-200 rounded w-1/3 mt-6"></div>
          <div className="space-y-2">
            <div className="h-4 bg-neutral-200 rounded"></div>
            <div className="h-4 bg-neutral-200 rounded"></div>
            <div className="h-4 bg-neutral-200 rounded"></div>
          </div>
        </div>
      </aside>
    );
  }
  
  return (
    <aside className="hidden md:block w-64 bg-white border-r border-neutral-200 p-4 space-y-6 h-full overflow-auto">
      <div>
        <h2 className="text-xs font-semibold uppercase text-neutral-500 mb-3">Sources</h2>
        <ul className="space-y-1">
          {sources.map((source) => (
            <li key={source.id}>
              <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                <Checkbox 
                  id={`source-${source.id}`} 
                  checked={selectedSources.includes(source.id)}
                  onCheckedChange={(checked) => handleSourceChange(source.id, checked as boolean)}
                />
                <Label htmlFor={`source-${source.id}`} className="cursor-pointer">{source.name}</Label>
              </div>
            </li>
          ))}
        </ul>
      </div>
      
      <div>
        <h2 className="text-xs font-semibold uppercase text-neutral-500 mb-3">Categories</h2>
        <ul className="space-y-1">
          {categories.map((category) => (
            <li key={category.id}>
              <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                <Checkbox 
                  id={`category-${category.id}`} 
                  checked={selectedCategories.includes(category.id)}
                  onCheckedChange={(checked) => handleCategoryChange(category.id, checked as boolean)}
                />
                <Label htmlFor={`category-${category.id}`} className="cursor-pointer">{category.name}</Label>
              </div>
            </li>
          ))}
        </ul>
      </div>
      
      <div>
        <h2 className="text-xs font-semibold uppercase text-neutral-500 mb-3">Publication Date</h2>
        <RadioGroup value={dateRange} onValueChange={setDateRange}>
          <div className="space-y-1">
            <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
              <RadioGroupItem value="24h" id="date-24h" />
              <Label htmlFor="date-24h" className="cursor-pointer">Last 24 hours</Label>
            </div>
            
            <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
              <RadioGroupItem value="week" id="date-week" />
              <Label htmlFor="date-week" className="cursor-pointer">Last week</Label>
            </div>
            
            <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
              <RadioGroupItem value="month" id="date-month" />
              <Label htmlFor="date-month" className="cursor-pointer">Last month</Label>
            </div>
            
            <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
              <RadioGroupItem value="year" id="date-year" />
              <Label htmlFor="date-year" className="cursor-pointer">Last year</Label>
            </div>
          </div>
        </RadioGroup>
      </div>
      
      <div className="pt-4 border-t border-neutral-200">
        <Button className="w-full" onClick={applyFilters}>
          Apply Filters
        </Button>
      </div>
    </aside>
  );
}

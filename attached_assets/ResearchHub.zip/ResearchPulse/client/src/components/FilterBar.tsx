import { Filter } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface FilterBarProps {
  totalPapers: number;
  onSort: (value: string) => void;
  onMobileFilterClick: () => void;
}

export default function FilterBar({ totalPapers, onSort, onMobileFilterClick }: FilterBarProps) {
  return (
    <div className="bg-white p-4 border-b border-neutral-200 flex justify-between items-center">
      <div className="flex space-x-2 items-center">
        <button 
          className="md:hidden p-2 text-neutral-500 hover:text-neutral-700 flex items-center"
          onClick={onMobileFilterClick}
        >
          <Filter className="h-4 w-4 mr-1" /> Filters
        </button>
        
        <div className="hidden md:flex items-center space-x-4">
          <span className="text-sm text-neutral-600">Sort by:</span>
          <Select defaultValue="newest" onValueChange={onSort}>
            <SelectTrigger className="text-sm border-none bg-transparent w-auto focus:ring-0 focus:ring-offset-0 p-0 h-auto">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest first</SelectItem>
              <SelectItem value="relevance">Relevance</SelectItem>
              <SelectItem value="citations">Most cited</SelectItem>
              <SelectItem value="title">Title A-Z</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="text-sm text-neutral-600">
        <span className="font-medium">{totalPapers}</span> papers found
      </div>
    </div>
  );
}

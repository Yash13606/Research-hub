import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useState, useEffect } from "react";
import { FilterOptions, Source, Category } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onFilterChange: (filters: FilterOptions) => void;
}

export default function MobileSidebar({ isOpen, onClose, onFilterChange }: MobileSidebarProps) {
  const { toast } = useToast();
  const [sources, setSources] = useState<Source[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedSources, setSelectedSources] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<string>("24h");
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch sources and categories
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sourcesRes, categoriesRes] = await Promise.all([
          fetch('/api/sources'),
          fetch('/api/categories')
        ]);
        
        if (!sourcesRes.ok || !categoriesRes.ok) {
          throw new Error('Failed to fetch filter data');
        }
        
        const sourcesData = await sourcesRes.json();
        const categoriesData = await categoriesRes.json();
        
        setSources(sourcesData);
        setCategories(categoriesData);
        
        // Default to all sources selected
        setSelectedSources(sourcesData.map((source: Source) => source.id));
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching filter data:', error);
        toast({
          title: "Error",
          description: "Failed to load filter options",
          variant: "destructive"
        });
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [toast]);
  
  // Handle source checkbox change
  const handleSourceChange = (sourceId: string, checked: boolean) => {
    setSelectedSources(prev => 
      checked 
        ? [...prev, sourceId] 
        : prev.filter(id => id !== sourceId)
    );
  };
  
  // Handle category checkbox change
  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    setSelectedCategories(prev => 
      checked 
        ? [...prev, categoryId] 
        : prev.filter(id => id !== categoryId)
    );
  };
  
  // Apply filters and close sidebar
  const applyFilters = () => {
    onFilterChange({
      sources: selectedSources,
      categories: selectedCategories,
      dateRange
    });
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-40 md:hidden">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-neutral-500 bg-opacity-75 transition-opacity" onClick={onClose}></div>
      
      {/* Sidebar */}
      <div className="absolute inset-y-0 left-0 max-w-xs w-full bg-white shadow-xl transform transition-transform">
        <div className="h-full flex flex-col">
          <div className="p-4 border-b border-neutral-200 flex justify-between items-center">
            <h2 className="font-medium text-lg">Filters</h2>
            <button className="p-2 text-neutral-500 hover:text-neutral-700" onClick={onClose}>
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {isLoading ? (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-neutral-200 rounded w-1/3"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-neutral-200 rounded"></div>
                  <div className="h-4 bg-neutral-200 rounded"></div>
                  <div className="h-4 bg-neutral-200 rounded"></div>
                </div>
              </div>
            ) : (
              <>
                <div>
                  <h2 className="text-xs font-semibold uppercase text-neutral-500 mb-3">Sources</h2>
                  <ul className="space-y-1">
                    {sources.map((source) => (
                      <li key={source.id}>
                        <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                          <Checkbox 
                            id={`mobile-source-${source.id}`} 
                            checked={selectedSources.includes(source.id)}
                            onCheckedChange={(checked) => handleSourceChange(source.id, checked as boolean)}
                          />
                          <Label htmlFor={`mobile-source-${source.id}`} className="cursor-pointer">{source.name}</Label>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h2 className="text-xs font-semibold uppercase text-neutral-500 mb-3">Categories</h2>
                  <ul className="space-y-1">
                    {categories.map((category) => (
                      <li key={category.id}>
                        <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                          <Checkbox 
                            id={`mobile-category-${category.id}`} 
                            checked={selectedCategories.includes(category.id)}
                            onCheckedChange={(checked) => handleCategoryChange(category.id, checked as boolean)}
                          />
                          <Label htmlFor={`mobile-category-${category.id}`} className="cursor-pointer">{category.name}</Label>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h2 className="text-xs font-semibold uppercase text-neutral-500 mb-3">Publication Date</h2>
                  <RadioGroup value={dateRange} onValueChange={setDateRange}>
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                        <RadioGroupItem value="24h" id="mobile-date-24h" />
                        <Label htmlFor="mobile-date-24h" className="cursor-pointer">Last 24 hours</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                        <RadioGroupItem value="week" id="mobile-date-week" />
                        <Label htmlFor="mobile-date-week" className="cursor-pointer">Last week</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                        <RadioGroupItem value="month" id="mobile-date-month" />
                        <Label htmlFor="mobile-date-month" className="cursor-pointer">Last month</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2 py-1 px-2 rounded hover:bg-neutral-100 cursor-pointer">
                        <RadioGroupItem value="year" id="mobile-date-year" />
                        <Label htmlFor="mobile-date-year" className="cursor-pointer">Last year</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>
              </>
            )}
          </div>
          
          <div className="p-4 border-t border-neutral-200">
            <Button className="w-full" onClick={applyFilters} disabled={isLoading}>
              Apply Filters
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

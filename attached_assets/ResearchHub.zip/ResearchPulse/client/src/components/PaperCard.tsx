import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bookmark, BookmarkCheck, FileText, Share, Loader2, ArrowRight, AlertTriangle } from "lucide-react";
import { Paper, Summary, SummaryType } from "@/lib/types";
import { formatDate, getSourceColor, truncateText } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";

interface PaperCardProps {
  paper: Paper;
}

export default function PaperCard({ paper }: PaperCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [summaryVisible, setSummaryVisible] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [summaryType, setSummaryType] = useState<SummaryType>('detailed');
  const [summaryError, setSummaryError] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  
  const sourceColors = getSourceColor(paper.source);
  
  // Check if the paper is already saved
  const { data: savedPapers } = useQuery({
    queryKey: ['/api/papers/saved'],
    queryFn: async () => {
      const res = await fetch('/api/papers/saved');
      if (!res.ok) {
        throw new Error('Failed to fetch saved papers');
      }
      return res.json();
    }
  });
  
  // Effect to check if paper is already saved when savedPapers data changes
  useEffect(() => {
    if (savedPapers) {
      // Check if this paper is in the saved papers list
      const isAlreadySaved = savedPapers.some((savedPaper: any) => savedPaper.paperId === paper.id);
      setIsSaved(isAlreadySaved);
    }
  }, [savedPapers, paper.id]);
  
  const { mutate: savePaper, isPending: isSavePending } = useMutation({
    mutationFn: async () => {
      try {
        const res = await apiRequest('POST', '/api/papers/save', {
          paperId: paper.id
        });
        
        if (!res.ok) {
          // If paper is already saved (409 Conflict)
          if (res.status === 409) {
            setIsSaved(true);
            return { alreadySaved: true };
          }
          
          const errorData = await res.json();
          throw new Error(errorData.message || 'Failed to save paper');
        }
        
        return res.json();
      } catch (error) {
        if (error instanceof Error) {
          throw error;
        } else {
          throw new Error('An unknown error occurred');
        }
      }
    },
    onSuccess: (data) => {
      setIsSaved(true);
      queryClient.invalidateQueries({ queryKey: ['/api/papers/saved'] });
      
      toast({
        title: "Paper Saved",
        description: "This paper has been added to your saved papers.",
      });
    },
    onError: (error: Error) => {
      console.error('Error saving paper:', error);
      
      toast({
        title: "Failed to Save Paper",
        description: error.message || "There was an error saving this paper. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  const { mutate: generateSummary, isPending } = useMutation({
    mutationFn: async () => {
      setSummaryError(null); // Reset error on new attempt
      
      try {
        const res = await apiRequest('POST', '/api/papers/summary', {
          paperId: paper.id,
          type: summaryType
        });
        
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.message || 'Failed to generate summary');
        }
        
        return res.json();
      } catch (error) {
        // Throw the error to be caught by onError
        if (error instanceof Error) {
          throw error;
        } else {
          throw new Error('An unknown error occurred');
        }
      }
    },
    onSuccess: (data: Summary) => {
      setSummary(data);
      setSummaryVisible(true);
      setSummaryError(null);
      queryClient.invalidateQueries({ queryKey: ['/api/papers'] });
    },
    onError: (error: Error) => {
      console.error('Error generating summary:', error);
      setSummaryError(error.message || 'Failed to generate summary. Please try again.');
      setSummaryVisible(true); // Show the error in the summary area
      
      toast({
        title: "Summary Generation Failed",
        description: error.message || "Failed to generate summary. Please try again later.",
        variant: "destructive"
      });
    }
  });
  
  const handleSummarize = () => {
    if (summaryVisible) {
      // Toggle summary visibility if already visible
      setSummaryVisible(false);
      // Reset error state when hiding
      if (summaryError) {
        setSummaryError(null);
      }
    } else {
      // Generate new summary
      generateSummary();
    }
  };
  
  const handleSummaryTypeChange = (type: SummaryType) => {
    setSummaryType(type);
    
    // If the summary is already visible, regenerate it with the new type
    if (summaryVisible) {
      generateSummary();
    }
  };
  
  const getSummaryContent = () => {
    if (!summary) return null;
    
    switch (summaryType) {
      case 'brief':
        return summary.briefSummary;
      case 'detailed':
        return summary.detailedSummary;
      case 'technical':
        return summary.technicalSummary;
      default:
        return summary.detailedSummary;
    }
  };
  
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center mb-1">
              <span className={`px-2 py-1 text-xs font-medium ${sourceColors.bg} ${sourceColors.text} rounded mr-2`}>
                {paper.source}
              </span>
              <span className="text-xs text-neutral-500">
                Published {formatDate(paper.publicationDate)}
              </span>
            </div>
            
            <h3 className="font-serif font-semibold text-lg mb-2">{paper.title}</h3>
            
            <p className="text-sm text-neutral-600 mb-3">
              <span className="font-medium">Authors:</span> {paper.authors}
            </p>
            
            <p className="text-sm text-neutral-600 line-clamp-3 mb-3">
              {paper.abstract}
            </p>
            
            <div className="flex flex-wrap gap-1 mb-3">
              {paper.categories.map((category, index) => (
                <Badge variant="outline" key={index} className="bg-neutral-100 hover:bg-neutral-200 text-neutral-800">
                  #{category}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="ml-4 flex-shrink-0 flex flex-col items-end">
            <button 
              className={`p-1 ${isSaved ? 'text-primary-600' : 'text-neutral-400 hover:text-primary-600'}`}
              onClick={() => !isSaved && savePaper()}
              disabled={isSavePending || isSaved}
              title={isSaved ? "Paper saved" : "Save paper"}
            >
              {isSavePending ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : isSaved ? (
                <BookmarkCheck className="h-5 w-5" />
              ) : (
                <Bookmark className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>
        
        {/* Summary Section */}
        {summaryVisible && (
          <div className="mt-3 border-t border-neutral-200 pt-3">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-medium text-sm">AI-Generated Summary</h4>
              {!summaryError && (
                <div className="flex space-x-1">
                  <button 
                    className={`px-2 py-1 text-xs font-medium rounded ${
                      summaryType === 'brief' 
                        ? 'border-primary-600 bg-primary-50 text-primary-700' 
                        : 'border border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700'
                    }`}
                    onClick={() => handleSummaryTypeChange('brief')}
                  >
                    Brief
                  </button>
                  <button 
                    className={`px-2 py-1 text-xs font-medium rounded ${
                      summaryType === 'detailed' 
                        ? 'border-primary-600 bg-primary-50 text-primary-700' 
                        : 'border border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700'
                    }`}
                    onClick={() => handleSummaryTypeChange('detailed')}
                  >
                    Detailed
                  </button>
                  <button 
                    className={`px-2 py-1 text-xs font-medium rounded ${
                      summaryType === 'technical' 
                        ? 'border-primary-600 bg-primary-50 text-primary-700' 
                        : 'border border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700'
                    }`}
                    onClick={() => handleSummaryTypeChange('technical')}
                  >
                    Technical
                  </button>
                </div>
              )}
            </div>
            <div className="bg-neutral-50 rounded-md p-3 text-sm">
              {isPending ? (
                <div className="flex items-center justify-center py-2">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  <p className="text-neutral-600">Generating summary...</p>
                </div>
              ) : summaryError ? (
                <div className="flex items-center p-2 bg-red-50 border border-red-100 rounded-md text-red-700">
                  <AlertTriangle className="h-4 w-4 mr-2 text-red-500" />
                  <p>{summaryError}</p>
                </div>
              ) : summary ? (
                <p className="text-neutral-700">
                  {getSummaryContent()}
                </p>
              ) : (
                <p className="text-neutral-500 italic">No summary available.</p>
              )}
            </div>
          </div>
        )}
        
        <div className="mt-3 flex justify-between items-center">
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" asChild>
              <a href={paper.url} target="_blank" rel="noopener noreferrer">
                <FileText className="h-4 w-4 mr-1" /> View Paper
              </a>
            </Button>
            <Button variant="outline" size="sm" onClick={handleSummarize} disabled={isPending}>
              {isPending ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <>
                  {summaryVisible ? (
                    <ArrowRight className="h-4 w-4 mr-1" />
                  ) : (
                    <div className="text-primary-600 mr-1">✨</div>
                  )}
                </>
              )}
              {summaryVisible ? "Hide Summary" : "Summarize"}
            </Button>
          </div>
          <div>
            <span className="text-xs text-neutral-500">Citations: {paper.citations}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

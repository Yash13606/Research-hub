import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Sidebar from '@/components/Sidebar';
import FilterBar from '@/components/FilterBar';
import PaperList from '@/components/PaperList';
import Footer from '@/components/Footer';
import MobileSidebar from '@/components/MobileSidebar';
import { FilterOptions } from '@/lib/types';
import { useQuery } from '@tanstack/react-query';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    sources: ['ArXiv'], // Default to ArXiv as a source to ensure we get papers
    categories: [],
    dateRange: ''
  });
  const [sortOption, setSortOption] = useState('newest');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  
  // Build query parameters for the count query
  const buildQueryParams = () => {
    const params = new URLSearchParams();
    
    if (filterOptions.sources.length > 0) {
      params.append('sources', filterOptions.sources.join(','));
    }
    
    if (filterOptions.categories.length > 0) {
      params.append('categories', filterOptions.categories.join(','));
    }
    
    if (filterOptions.dateRange) {
      params.append('dateRange', filterOptions.dateRange);
    }
    
    if (searchQuery) {
      params.append('search', searchQuery);
    }
    
    return params.toString();
  };
  
  // Get total papers count with filters applied
  const { data, refetch } = useQuery({
    queryKey: ['/api/papers', 'count', searchQuery, filterOptions],
    queryFn: async () => {
      const queryParams = buildQueryParams();
      const url = `/api/papers?${queryParams}&limit=1`;
      const response = await fetch(url);
      if (!response.ok) throw new Error('Failed to fetch paper count');
      return response.json();
    }
  });
  
  // Refetch when filters change
  useEffect(() => {
    refetch();
  }, [searchQuery, filterOptions, refetch]);
  
  const totalPapers = data?.total || 0;
  
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };
  
  const handleFilterChange = (filters: FilterOptions) => {
    setFilterOptions(filters);
  };
  
  const handleSortChange = (value: string) => {
    setSortOption(value);
  };
  
  const toggleMobileSidebar = () => {
    setIsMobileSidebarOpen(!isMobileSidebarOpen);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onSearch={handleSearch} />
      
      <main className="flex-1 flex">
        <Sidebar onFilterChange={handleFilterChange} />
        
        <div className="flex-1 overflow-auto">
          <FilterBar 
            totalPapers={totalPapers} 
            onSort={handleSortChange}
            onMobileFilterClick={toggleMobileSidebar}
          />
          
          <PaperList 
            searchQuery={searchQuery}
            filterOptions={filterOptions}
            sortOption={sortOption}
          />
        </div>
      </main>
      
      <Footer />
      
      <MobileSidebar 
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        onFilterChange={handleFilterChange}
      />
    </div>
  );
}

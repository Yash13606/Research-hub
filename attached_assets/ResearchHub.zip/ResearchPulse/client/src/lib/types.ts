// Paper type
export interface Paper {
  id: number;
  title: string;
  authors: string;
  abstract: string;
  publicationDate: string;
  source: string;
  sourceId: string;
  url: string;
  categories: string[];
  citations: number;
}

// Summary type
export interface Summary {
  id: number;
  paperId: number;
  briefSummary?: string;
  detailedSummary?: string;
  technicalSummary?: string;
  generatedAt: string;
}

// Filter type
export interface FilterOptions {
  sources: string[];
  categories: string[];
  dateRange: string;
}

export interface Source {
  id: string;
  name: string;
}

export interface Category {
  id: string;
  name: string;
}

// Summary type enum
export type SummaryType = 'brief' | 'detailed' | 'technical';

// API response types
export interface PapersResponse {
  papers: Paper[];
  total: number;
}

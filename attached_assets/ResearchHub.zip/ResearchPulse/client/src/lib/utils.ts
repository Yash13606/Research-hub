import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

export function debounce<F extends (...args: any[]) => any>(
  func: F,
  waitFor: number
) {
  let timeout: ReturnType<typeof setTimeout> | null = null;

  const debounced = (...args: Parameters<F>) => {
    if (timeout !== null) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => func(...args), waitFor);
  };

  return debounced as (...args: Parameters<F>) => ReturnType<F>;
}

export function extractAuthorsFromString(authors: string): string[] {
  return authors.split(',').map(author => author.trim());
}

export function getSourceColor(source: string): { bg: string; text: string } {
  switch (source) {
    case 'ArXiv':
      return { bg: 'bg-primary-100', text: 'text-primary-800' };
    case 'IEEE':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'PubMed':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'ScienceDirect':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800' };
    case 'Springer':
      return { bg: 'bg-purple-100', text: 'text-purple-800' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-800' };
  }
}

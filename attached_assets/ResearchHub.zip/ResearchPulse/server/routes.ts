import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { paperQuerySchema, summaryRequestSchema, savedPaperRequestSchema } from "@shared/schema";
import { fetchAllPapers } from "./services/paperService";
import { generateSummary } from "./services/geminiService";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Prefetch papers when server starts
  fetchAllPapers().catch(err => {
    console.error("Error prefetching papers:", err);
  });
  
  // Periodically fetch new papers (every hour)
  setInterval(() => {
    fetchAllPapers().catch(err => {
      console.error("Error fetching new papers:", err);
    });
  }, 3600000); // 1 hour
  
  // Get all papers with filtering
  app.get("/api/papers", async (req: Request, res: Response) => {
    try {
      const query = {
        search: req.query.search as string | undefined,
        sources: req.query.sources ? (req.query.sources as string).split(",") : undefined,
        categories: req.query.categories ? (req.query.categories as string).split(",") : undefined,
        dateRange: req.query.dateRange as string | undefined,
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 10,
      };
      
      // Validate query params
      const validatedQuery = paperQuerySchema.parse(query);
      
      // Get papers from storage
      const result = await storage.getPapers(validatedQuery);
      
      res.json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Error getting papers:", error);
        res.status(500).json({ message: "Error retrieving papers" });
      }
    }
  });
  
  // Get a single paper by ID
  app.get("/api/papers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid paper ID" });
      }
      
      const paper = await storage.getPaper(id);
      
      if (!paper) {
        return res.status(404).json({ message: "Paper not found" });
      }
      
      res.json(paper);
    } catch (error) {
      console.error("Error getting paper:", error);
      res.status(500).json({ message: "Error retrieving paper" });
    }
  });
  
  // Generate a summary for a paper
  app.post("/api/papers/summary", async (req: Request, res: Response) => {
    try {
      const requestData = summaryRequestSchema.parse(req.body);
      
      // Check if Gemini API key is available
      if (!process.env.GEMINI_API_KEY) {
        console.error("GEMINI_API_KEY is not set");
        return res.status(503).json({ 
          message: "Summary generation is currently unavailable. API key is not configured."
        });
      }
      
      const summary = await generateSummary(requestData.paperId, requestData.type);
      
      if (!summary) {
        console.error("Summary generation failed for paper ID:", requestData.paperId);
        return res.status(500).json({ 
          message: "Failed to generate summary. Please try again later." 
        });
      }
      
      res.json(summary);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        // Log the full error for debugging
        console.error("Error generating summary:", error);
        
        if (error instanceof Error) {
          // If it's an API or connection related error, return more specific message
          if (error.message.includes('API') || error.message.includes('models/')) {
            return res.status(503).json({ 
              message: "Summary generation service is currently unavailable. Please try again later."
            });
          }
        }
        
        res.status(500).json({ 
          message: "Unable to generate summary. Please try again later." 
        });
      }
    }
  });
  
  // Get sources (for filters)
  app.get("/api/sources", async (req: Request, res: Response) => {
    try {
      // In a real implementation, we would query the database for unique sources
      // For now, return hardcoded sources
      const sources = [
        { id: "ArXiv", name: "ArXiv" },
        { id: "IEEE", name: "IEEE Xplore" },
        { id: "PubMed", name: "PubMed" },
        { id: "Springer", name: "Springer" },
        { id: "ScienceDirect", name: "ScienceDirect" }
      ];
      
      res.json(sources);
    } catch (error) {
      console.error("Error getting sources:", error);
      res.status(500).json({ message: "Error retrieving sources" });
    }
  });
  
  // Get categories (for filters)
  app.get("/api/categories", async (req: Request, res: Response) => {
    try {
      // In a real implementation, we would query the database for unique categories
      // For now, return hardcoded categories
      const categories = [
        { id: "cs.AI", name: "Computer Science - Artificial Intelligence" },
        { id: "cs.LG", name: "Computer Science - Machine Learning" },
        { id: "cs.CL", name: "Computer Science - Computation and Language" },
        { id: "math", name: "Mathematics" },
        { id: "physics", name: "Physics" },
        { id: "biology", name: "Biology" },
        { id: "medicine", name: "Medicine" }
      ];
      
      res.json(categories);
    } catch (error) {
      console.error("Error getting categories:", error);
      res.status(500).json({ message: "Error retrieving categories" });
    }
  });
  
  // Save a paper
  app.post("/api/papers/save", async (req: Request, res: Response) => {
    try {
      const requestData = savedPaperRequestSchema.parse(req.body);
      
      // Check if paper exists
      const paper = await storage.getPaper(requestData.paperId);
      if (!paper) {
        return res.status(404).json({ message: "Paper not found" });
      }
      
      // Check if paper is already saved (if we're using a user ID)
      // For now, we'll simply check if any saved paper exists with this paperId
      const existingSavedPaper = await storage.getSavedPaper(requestData.paperId);
      
      if (existingSavedPaper) {
        return res.status(409).json({ 
          message: "Paper already saved",
          savedPaper: existingSavedPaper
        });
      }
      
      // Create saved paper
      const savedPaper = await storage.createSavedPaper({ 
        paperId: requestData.paperId,
        // In a real app with auth, we'd use the authenticated user's ID
        userId: null  
      });
      
      res.status(201).json(savedPaper);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Error saving paper:", error);
        res.status(500).json({ message: "Error saving paper" });
      }
    }
  });
  
  // Get saved papers
  app.get("/api/papers/saved", async (req: Request, res: Response) => {
    try {
      // In a real app with auth, we'd filter by the authenticated user's ID
      const savedPapers = await storage.getSavedPapers();
      
      // Add paper details to saved papers to display in the UI
      const savedPapersWithDetails = await Promise.all(
        savedPapers.map(async (savedPaper) => {
          const paper = await storage.getPaper(savedPaper.paperId);
          return {
            ...savedPaper,
            paper
          };
        })
      );
      
      res.json(savedPapers);
    } catch (error) {
      console.error("Error getting saved papers:", error);
      res.status(500).json({ message: "Error retrieving saved papers" });
    }
  });
  
  // Unsave a paper
  app.delete("/api/papers/saved/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const result = await storage.deleteSavedPaper(id);
      
      if (!result) {
        return res.status(404).json({ message: "Saved paper not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error unsaving paper:", error);
      res.status(500).json({ message: "Error unsaving paper" });
    }
  });
  
  // Initialize the HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}

import axios from 'axios';
import { Paper, InsertPaper } from '@shared/schema';
import { storage } from '../storage';
import * as xml2js from 'xml2js';

// Cache for papers to avoid unnecessary API calls
const paperCache = new Map<string, { papers: InsertPaper[], timestamp: number }>();
const CACHE_DURATION = 3600000; // 1 hour in milliseconds

interface ArxivPaper {
  id: string;
  title: string;
  authors: { name: string }[];
  summary: string;
  published: string;
  categories: string[];
}

interface IEEEPaper {
  articleNumber: string;
  title: string;
  authors: { full_name: string }[];
  abstract: string;
  publication_date: string;
  index_terms: { ieee_terms: string[] };
  citing_paper_count: number;
}

// Fetch papers from ArXiv
async function fetchArxivPapers(): Promise<InsertPaper[]> {
  try {
    // Use ArXiv API to fetch recent papers
    const response = await axios.get(
      'http://export.arxiv.org/api/query?search_query=cat:cs.AI+OR+cat:cs.LG+OR+cat:cs.CL&sortBy=submittedDate&sortOrder=descending&max_results=50'
    );
    
    // Parse XML using xml2js
    const parser = new xml2js.Parser({ explicitArray: false });
    const result = await parser.parseStringPromise(response.data);
    
    // Extract feed and entries from the parsed XML
    const feed = result.feed;
    const entries = Array.isArray(feed.entry) ? feed.entry : [feed.entry];
    
    const papers: InsertPaper[] = [];
    
    // Process each entry
    for (const entry of entries) {
      if (!entry) continue;

      const id = entry.id || '';
      const title = entry.title || '';
      
      // Handle authors (could be an array or single object)
      let authorList = [];
      if (Array.isArray(entry.author)) {
        authorList = entry.author.map(author => author.name || '');
      } else if (entry.author) {
        authorList = [entry.author.name || ''];
      }
      const authors = authorList.join(', ');
      
      const summary = entry.summary || '';
      const published = entry.published || '';
      
      // Handle categories (could be an array or single object)
      let categoryList = [];
      if (Array.isArray(entry.category)) {
        categoryList = entry.category.map(cat => cat.$.term || '');
      } else if (entry.category) {
        categoryList = [entry.category.$.term || ''];
      }
      
      papers.push({
        title,
        authors,
        abstract: summary,
        publicationDate: new Date(published),
        source: 'ArXiv',
        sourceId: id.split('/').pop() || '',
        url: id,
        categories: categoryList,
        citations: Math.floor(Math.random() * 100) // ArXiv doesn't provide citation count in API
      });
    }
    
    return papers;
  } catch (error) {
    console.error('Error fetching ArXiv papers:', error);
    return [];
  }
}

// Mock function for PubMed papers (in a real app, would use actual PubMed API)
async function fetchPubMedPapers(): Promise<InsertPaper[]> {
  try {
    // For a real implementation, we would use the PubMed API
    // This mock function returns an empty array for now
    return [];
  } catch (error) {
    console.error('Error fetching PubMed papers:', error);
    return [];
  }
}

// Mock function for IEEE papers (in a real app, would use actual IEEE API)
async function fetchIEEEPapers(): Promise<InsertPaper[]> {
  try {
    // For a real implementation, we would use the IEEE API
    // This mock function returns an empty array for now
    return [];
  } catch (error) {
    console.error('Error fetching IEEE papers:', error);
    return [];
  }
}

// Fetch papers from all sources and store them
export async function fetchAllPapers(): Promise<Paper[]> {
  const cacheKey = 'all-papers';
  const cachedData = paperCache.get(cacheKey);
  
  // Return cached papers if they're not expired
  if (cachedData && (Date.now() - cachedData.timestamp < CACHE_DURATION)) {
    // Convert cached InsertPapers to Papers through storage to get IDs
    const paperPromises = cachedData.papers.map(async (paper) => {
      // Check if paper already exists in storage by title and source
      const { papers: existingPapers } = await storage.getPapers({
        search: paper.title,
      });
      
      const existingPaper = existingPapers.find(p => 
        p.title === paper.title && p.source === paper.source
      );
      
      if (existingPaper) {
        return existingPaper;
      } else {
        return await storage.createPaper(paper);
      }
    });
    
    return Promise.all(paperPromises);
  }
  
  // Fetch papers from all sources
  const [arxivPapers, pubmedPapers, ieeePapers] = await Promise.all([
    fetchArxivPapers(),
    fetchPubMedPapers(),
    fetchIEEEPapers(),
  ]);
  
  // Combine all papers
  const allPapers = [...arxivPapers, ...pubmedPapers, ...ieeePapers];
  
  // Update cache
  paperCache.set(cacheKey, {
    papers: allPapers,
    timestamp: Date.now()
  });
  
  // Store papers in database and return them with IDs
  const paperPromises = allPapers.map(async (paper) => {
    // Check if paper already exists in storage by title and source
    const { papers: existingPapers } = await storage.getPapers({
      search: paper.title,
    });
    
    const existingPaper = existingPapers.find(p => 
      p.title === paper.title && p.source === paper.source
    );
    
    if (existingPaper) {
      return existingPaper;
    } else {
      return await storage.createPaper(paper);
    }
  });
  
  return Promise.all(paperPromises);
}

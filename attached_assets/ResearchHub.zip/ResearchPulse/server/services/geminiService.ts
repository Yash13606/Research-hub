import { GoogleGenerativeAI } from '@google/generative-ai';
import { storage } from '../storage';
import { Summary } from '@shared/schema';

// Initialize Gemini API with proper version
const API_KEY = process.env.GEMINI_API_KEY || '';
const genAI = new GoogleGenerativeAI(API_KEY);

// Prompts for different summary types
const SUMMARY_PROMPTS = {
  brief: "Provide a brief, concise summary (1-2 sentences) of this academic paper that captures its main contribution:",
  detailed: "Provide a detailed summary (3-4 paragraphs) of this academic paper, including methodology, results, and significance:",
  technical: "Provide a technical summary of this academic paper with specific focus on methodologies, algorithms, and technical contributions:"
};

// Available models as of March 2025
const AVAILABLE_MODELS = [
  "gemini-pro", // Try the standard model first
  "gemini-1.0-pro", // Try version-specific model 
  "gemini-1.5-pro", // Latest model
  "gemini-1.5-flash", // Faster, more efficient model
  "models/gemini-pro" // With models/ prefix
];

// Test each model at startup to find the working one
async function testModels() {
  console.log("Testing available Gemini models...");
  for (const modelName of AVAILABLE_MODELS) {
    try {
      const model = genAI.getGenerativeModel({ model: modelName });
      const result = await model.generateContent("Hello, can you respond with just the word 'working'?");
      const response = await result.response;
      console.log(`✅ Model ${modelName} is working! Response: ${response.text().substring(0, 20)}...`);
      return modelName; // Return the first working model
    } catch (e: any) {
      console.error(`❌ Model ${modelName} failed:`, e?.message || String(e));
      // Continue to next model
    }
  }
  console.error("⚠️ No Gemini models are working!");
  return null;
}

// Execute test (but don't block startup)
const WORKING_MODEL_PROMISE = testModels();

// Generate summary for a paper
export async function generateSummary(
  paperId: number, 
  summaryType: "brief" | "detailed" | "technical"
): Promise<Summary | undefined> {
  try {
    // Get the paper by ID
    const paper = await storage.getPaper(paperId);
    
    if (!paper) {
      throw new Error(`Paper with ID ${paperId} not found`);
    }
    
    // Check if summary already exists
    const existingSummary = await storage.getSummary(paperId);
    
    // If summary of requested type already exists, return it
    if (
      existingSummary && 
      (
        (summaryType === "brief" && existingSummary.briefSummary) ||
        (summaryType === "detailed" && existingSummary.detailedSummary) ||
        (summaryType === "technical" && existingSummary.technicalSummary)
      )
    ) {
      return existingSummary;
    }
    
    // First, check if we already identified a working model during startup
    let workingModel: string | null = null;
    try {
      workingModel = await WORKING_MODEL_PROMISE;
      if (workingModel) {
        console.log(`Using known working model: ${workingModel}`);
      }
    } catch (e: any) {
      console.error("Error retrieving working model:", e?.message || String(e));
    }
    
    // If we have a working model, try it first
    let generatedSummary = '';
    let error = null;
    
    // If we have a working model, try it first, otherwise try all models
    const modelsToTry = workingModel ? [workingModel, ...AVAILABLE_MODELS] : AVAILABLE_MODELS;
    
    // Try each model until one works
    for (const modelName of modelsToTry) {
      try {
        // Generate new summary with Gemini using current model
        const model = genAI.getGenerativeModel({ model: modelName });
        
        // Combine paper title, abstract, and prompt for context
        const prompt = `
          Title: ${paper.title}
          Authors: ${paper.authors}
          Abstract: ${paper.abstract}
          
          ${SUMMARY_PROMPTS[summaryType]}
        `;
        
        // Generate summary
        console.log(`Attempting to generate summary with model: ${modelName}`);
        const result = await model.generateContent(prompt);
        const response = await result.response;
        generatedSummary = response.text();
        
        // If we get here, the model worked
        console.log(`Successfully generated summary with model: ${modelName}`);
        break;
      } catch (e: any) {
        console.error(`Error with model ${modelName}:`, e?.message || String(e));
        error = e;
        // Continue to try the next model
      }
    }
    
    // If no models worked
    if (!generatedSummary) {
      console.error('All Gemini models failed:', error);
      throw new Error('Failed to generate summary with any available model');
    }
    
    // Create or update summary in storage
    if (existingSummary) {
      // Update existing summary with new generated content
      const summaryUpdate = {
        ...(summaryType === "brief" && { briefSummary: generatedSummary }),
        ...(summaryType === "detailed" && { detailedSummary: generatedSummary }),
        ...(summaryType === "technical" && { technicalSummary: generatedSummary }),
      };
      
      return await storage.updateSummary(existingSummary.id, summaryUpdate);
    } else {
      // Create new summary
      const newSummary = {
        paperId,
        briefSummary: summaryType === "brief" ? generatedSummary : undefined,
        detailedSummary: summaryType === "detailed" ? generatedSummary : undefined,
        technicalSummary: summaryType === "technical" ? generatedSummary : undefined,
      };
      
      return await storage.createSummary(newSummary);
    }
  } catch (error: any) {
    console.error('Error generating summary:', error?.message || String(error));
    return undefined;
  }
}

import { users, papers, summaries, filters, savedPapers, type User, type InsertUser, type Paper, type InsertPaper, type Summary, type InsertSummary, type Filter, type InsertFilter, type PaperQuery, type SavedPaper, type InsertSavedPaper } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Paper methods
  getPaper(id: number): Promise<Paper | undefined>;
  getPapers(query: PaperQuery): Promise<{ papers: Paper[], total: number }>;
  createPaper(paper: InsertPaper): Promise<Paper>;
  updatePaper(id: number, paper: Partial<InsertPaper>): Promise<Paper | undefined>;
  
  // Summary methods
  getSummary(paperId: number): Promise<Summary | undefined>;
  createSummary(summary: InsertSummary): Promise<Summary>;
  updateSummary(id: number, summary: Partial<InsertSummary>): Promise<Summary | undefined>;
  
  // Saved Paper methods
  getSavedPapers(userId?: number): Promise<SavedPaper[]>;
  getSavedPaper(paperId: number, userId?: number): Promise<SavedPaper | undefined>;
  createSavedPaper(savedPaper: InsertSavedPaper): Promise<SavedPaper>;
  deleteSavedPaper(id: number): Promise<boolean>;
  
  // Filter methods
  getFilter(userId: number): Promise<Filter | undefined>;
  createFilter(filter: InsertFilter): Promise<Filter>;
  updateFilter(id: number, filter: Partial<InsertFilter>): Promise<Filter | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private papers: Map<number, Paper>;
  private summaries: Map<number, Summary>;
  private filters: Map<number, Filter>;
  private savedPapers: Map<number, SavedPaper>;
  
  private userCurrentId: number;
  private paperCurrentId: number;
  private summaryCurrentId: number;
  private filterCurrentId: number;
  private savedPaperCurrentId: number;

  constructor() {
    this.users = new Map();
    this.papers = new Map();
    this.summaries = new Map();
    this.filters = new Map();
    this.savedPapers = new Map();
    
    this.userCurrentId = 1;
    this.paperCurrentId = 1;
    this.summaryCurrentId = 1;
    this.filterCurrentId = 1;
    this.savedPaperCurrentId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Paper methods
  async getPaper(id: number): Promise<Paper | undefined> {
    return this.papers.get(id);
  }
  
  async getPapers(query: PaperQuery): Promise<{ papers: Paper[], total: number }> {
    let filteredPapers = Array.from(this.papers.values());
    
    // Apply search filter if provided
    if (query.search) {
      const searchLower = query.search.toLowerCase();
      filteredPapers = filteredPapers.filter(paper => 
        paper.title.toLowerCase().includes(searchLower) || 
        paper.authors.toLowerCase().includes(searchLower) || 
        paper.abstract.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply sources filter if provided
    if (query.sources && query.sources.length > 0) {
      filteredPapers = filteredPapers.filter(paper => 
        query.sources!.includes(paper.source)
      );
    }
    
    // Apply categories filter if provided
    if (query.categories && query.categories.length > 0) {
      filteredPapers = filteredPapers.filter(paper => 
        paper.categories.some(category => query.categories!.includes(category))
      );
    }
    
    // Apply date range filter if provided
    if (query.dateRange) {
      const now = new Date();
      let startDate = new Date();
      
      switch (query.dateRange) {
        case "24h":
          startDate.setDate(now.getDate() - 1);
          break;
        case "week":
          startDate.setDate(now.getDate() - 7);
          break;
        case "month":
          startDate.setMonth(now.getMonth() - 1);
          break;
        case "year":
          startDate.setFullYear(now.getFullYear() - 1);
          break;
      }
      
      filteredPapers = filteredPapers.filter(paper => 
        new Date(paper.publicationDate) >= startDate
      );
    }
    
    // Sort by publication date (newest first)
    filteredPapers.sort((a, b) => 
      new Date(b.publicationDate).getTime() - new Date(a.publicationDate).getTime()
    );
    
    // Apply pagination
    const page = query.page || 1;
    const limit = query.limit || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    
    const paginatedPapers = filteredPapers.slice(startIndex, endIndex);
    
    return {
      papers: paginatedPapers,
      total: filteredPapers.length
    };
  }
  
  async createPaper(paper: InsertPaper): Promise<Paper> {
    const id = this.paperCurrentId++;
    const newPaper: Paper = { 
      ...paper, 
      id,
      citations: paper.citations ?? 0
    };
    this.papers.set(id, newPaper);
    return newPaper;
  }
  
  async updatePaper(id: number, paperUpdate: Partial<InsertPaper>): Promise<Paper | undefined> {
    const existingPaper = this.papers.get(id);
    
    if (!existingPaper) {
      return undefined;
    }
    
    const updatedPaper = { ...existingPaper, ...paperUpdate };
    this.papers.set(id, updatedPaper);
    
    return updatedPaper;
  }
  
  // Summary methods
  async getSummary(paperId: number): Promise<Summary | undefined> {
    return Array.from(this.summaries.values()).find(
      (summary) => summary.paperId === paperId
    );
  }
  
  async createSummary(summary: InsertSummary): Promise<Summary> {
    const id = this.summaryCurrentId++;
    const newSummary: Summary = { 
      ...summary, 
      id, 
      briefSummary: summary.briefSummary ?? null,
      detailedSummary: summary.detailedSummary ?? null,
      technicalSummary: summary.technicalSummary ?? null,
      generatedAt: new Date() 
    };
    this.summaries.set(id, newSummary);
    return newSummary;
  }
  
  async updateSummary(id: number, summaryUpdate: Partial<InsertSummary>): Promise<Summary | undefined> {
    const existingSummary = this.summaries.get(id);
    
    if (!existingSummary) {
      return undefined;
    }
    
    const updatedSummary = { ...existingSummary, ...summaryUpdate };
    this.summaries.set(id, updatedSummary);
    
    return updatedSummary;
  }
  
  // Filter methods
  async getFilter(userId: number): Promise<Filter | undefined> {
    return Array.from(this.filters.values()).find(
      (filter) => filter.userId === userId
    );
  }
  
  async createFilter(filter: InsertFilter): Promise<Filter> {
    const id = this.filterCurrentId++;
    const newFilter: Filter = { 
      ...filter, 
      id,
      sources: filter.sources ?? null,
      categories: filter.categories ?? null,
      dateRange: filter.dateRange ?? null,
      userId: filter.userId ?? null,
      lastUpdated: new Date()
    };
    this.filters.set(id, newFilter);
    return newFilter;
  }
  
  async updateFilter(id: number, filterUpdate: Partial<InsertFilter>): Promise<Filter | undefined> {
    const existingFilter = this.filters.get(id);
    
    if (!existingFilter) {
      return undefined;
    }
    
    const updatedFilter = { 
      ...existingFilter, 
      ...filterUpdate,
      lastUpdated: new Date()
    };
    this.filters.set(id, updatedFilter);
    
    return updatedFilter;
  }
  
  // Saved Papers methods
  async getSavedPapers(userId?: number): Promise<SavedPaper[]> {
    const allSavedPapers = Array.from(this.savedPapers.values());
    
    if (userId) {
      return allSavedPapers.filter(savedPaper => savedPaper.userId === userId);
    }
    
    return allSavedPapers;
  }
  
  async getSavedPaper(paperId: number, userId?: number): Promise<SavedPaper | undefined> {
    const allSavedPapers = Array.from(this.savedPapers.values());
    
    if (userId) {
      return allSavedPapers.find(
        savedPaper => savedPaper.paperId === paperId && savedPaper.userId === userId
      );
    }
    
    return allSavedPapers.find(savedPaper => savedPaper.paperId === paperId);
  }
  
  async createSavedPaper(savedPaper: InsertSavedPaper): Promise<SavedPaper> {
    const id = this.savedPaperCurrentId++;
    const newSavedPaper: SavedPaper = {
      ...savedPaper,
      id,
      userId: savedPaper.userId ?? null,
      savedAt: new Date()
    };
    this.savedPapers.set(id, newSavedPaper);
    return newSavedPaper;
  }
  
  async deleteSavedPaper(id: number): Promise<boolean> {
    return this.savedPapers.delete(id);
  }
}

export const storage = new MemStorage();

import axios from "axios";
import { XMLParser } from "fast-xml-parser";
import { Paper } from "@/lib/types";

export async function fetchArxivPapers(
  query: string = "",
  categories: string[] = [],
  dateRange: string = "any",
  dateStart?: string,
  dateEnd?: string
): Promise<Paper[]> {
  try {
    // Build the arXiv API query
    let apiQuery = "";
    
    if (query) {
      apiQuery += `all:${query}`;
    }
    
    if (categories.length > 0) {
      const categoryMap: Record<string, string> = {
        "Computer Science": "cs",
        "Physics": "physics",
        "Mathematics": "math",
        "Biology": "q-bio",
        "Medicine": "q-bio.TO",
      };
      
      const catQueries = categories
        .map(cat => categoryMap[cat])
        .filter(Boolean)
        .map(code => `cat:${code}`)
        .join("+OR+");
      
      if (catQueries) {
        apiQuery += apiQuery ? `+AND+(${catQueries})` : catQueries;
      }
    }
    
    // Handle date filtering
    // arXiv API doesn't support direct date filtering, so we'll filter results after fetching
    
    // Build the API URL
    const baseUrl = "http://export.arxiv.org/api/query";
    const url = `${baseUrl}?search_query=${encodeURIComponent(apiQuery)}&start=0&max_results=50&sortBy=submittedDate&sortOrder=descending`;
    
    const response = await axios.get(url);
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: "_",
    });
    const result = parser.parse(response.data);
    
    // Extract papers from the response
    const entries = result.feed.entry || [];
    const papers = Array.isArray(entries) ? entries : [entries];
    
    return papers.map((paper: any) => {
      // Parse the date
      const publishDate = new Date(paper.published);
      
      // Apply date filtering
      if (dateRange !== "any") {
        const now = new Date();
        let startDate: Date;
        
        switch (dateRange) {
          case "week":
            startDate = new Date(now.setDate(now.getDate() - 7));
            break;
          case "month":
            startDate = new Date(now.setMonth(now.getMonth() - 1));
            break;
          case "year":
            startDate = new Date(now.setFullYear(now.getFullYear() - 1));
            break;
          case "custom":
            if (dateStart && dateEnd) {
              if (
                publishDate < new Date(dateStart) || 
                publishDate > new Date(dateEnd)
              ) {
                return null;
              }
            }
            break;
          default:
            startDate = new Date(0); // beginning of time
        }
        
        if (dateRange !== "custom" && publishDate < startDate) {
          return null;
        }
      }
      
      // Extract authors
      const authors = Array.isArray(paper.author) 
        ? paper.author.map((author: any) => author.name) 
        : [paper.author.name];
      
      // Extract categories
      const primaryCategory = paper.category ? paper.category._term : "";
      const categoriesMap: Record<string, string> = {
        "cs": "Computer Science",
        "physics": "Physics",
        "math": "Mathematics",
        "q-bio": "Biology",
        "q-bio.TO": "Medicine",
      };
      
      const category = primaryCategory.split('.')[0];
      const mappedCategory = categoriesMap[category] || primaryCategory;
      
      // Extract keywords (arXiv doesn't provide keywords directly, so extract from title/abstract)
      const keywordExtractor = (text: string) => {
        const commonWords = ["and", "or", "the", "a", "an", "in", "on", "of", "to", "for", "with"];
        const words = text.toLowerCase().match(/\b(\w+)\b/g) || [];
        return [...new Set(words)]
          .filter(word => word.length > 3 && !commonWords.includes(word))
          .slice(0, 5);
      };
      
      const keywords = keywordExtractor(paper.title + " " + paper.summary);
      
      return {
        id: paper.id.split('/').pop()?.split('v')[0] || paper.id,
        title: paper.title,
        authors,
        abstract: paper.summary,
        url: paper.id,
        publishDate: publishDate.toISOString(),
        source: "arXiv",
        category: mappedCategory,
        keywords,
      };
    }).filter(Boolean) as Paper[];
  } catch (error) {
    console.error("Error fetching from arXiv:", error);
    return [];
  }
}

import OpenAI from "openai";
import axios from "axios";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Fetch paper details for summarization
async function fetchPaperDetails(paperId: string): Promise<{
  title: string;
  abstract: string;
  fullText?: string;
}> {
  // In a real implementation, you would fetch this from your database
  // or from the appropriate API (arXiv, PubMed, Semantic Scholar)
  
  // For demo purposes, try to get some details from an API
  try {
    // Try first with arXiv API
    if (paperId.includes('.')) {
      const response = await axios.get(`http://export.arxiv.org/api/query?id_list=${paperId}`);
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(response.data, "text/xml");
      const title = xmlDoc.querySelector("entry > title")?.textContent || "";
      const abstract = xmlDoc.querySelector("entry > summary")?.textContent || "";
      
      return { title, abstract };
    }
    
    // Try with PubMed
    if (!isNaN(Number(paperId))) {
      const response = await axios.get(`https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${paperId}&retmode=xml`);
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(response.data, "text/xml");
      const title = xmlDoc.querySelector("ArticleTitle")?.textContent || "";
      const abstract = xmlDoc.querySelector("AbstractText")?.textContent || "";
      
      return { title, abstract };
    }
    
    // Try with Semantic Scholar
    const response = await axios.get(`https://api.semanticscholar.org/graph/v1/paper/${paperId}?fields=title,abstract`);
    return {
      title: response.data.title || "",
      abstract: response.data.abstract || "",
    };
  } catch (error) {
    console.error("Error fetching paper details:", error);
    return {
      title: "Unknown paper",
      abstract: "No abstract available",
    };
  }
}

export async function generateSummary(
  paperId: string,
  length: string = "short"
): Promise<string> {
  try {
    // Get the paper details
    const paperDetails = await fetchPaperDetails(paperId);
    
    // If we couldn't get any details, return an error message
    if (!paperDetails.title && !paperDetails.abstract) {
      return "Could not find paper details to generate a summary.";
    }
    
    // Determine the word count based on the summary length
    let wordCount: number;
    let detailLevel: string;
    
    switch (length) {
      case "medium":
        wordCount = 250;
        detailLevel = "moderate";
        break;
      case "detailed":
        wordCount = 500;
        detailLevel = "in-depth";
        break;
      case "short":
      default:
        wordCount = 100;
        detailLevel = "brief";
        break;
    }
    
    // Create the prompt for OpenAI
    const prompt = `
      You are a scientific research assistant specializing in creating concise summaries of research papers.
      
      Please create a ${detailLevel} HTML-formatted summary of the following research paper. 
      The summary should be approximately ${wordCount} words and highlight the key points, methodology, results, and significance of the paper.
      
      Paper Title: ${paperDetails.title}
      Paper Abstract: ${paperDetails.abstract}
      ${paperDetails.fullText ? `Paper Full Text: ${paperDetails.fullText}` : ""}
      
      Format the summary with HTML tags:
      - Use <h5> tags for section headers like "Key Points", "Methodology", "Results", "Significance"
      - Use <ul> and <li> for listing key points
      - Use <p> for paragraphs
      
      The summary should be well-structured, informative, and highlight the most important aspects of the research.
    `;
    
    // Generate the summary using OpenAI
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1000,
    });
    
    // Return the generated summary
    return response.choices[0].message.content || "Failed to generate summary.";
  } catch (error) {
    console.error("Error generating summary:", error);
    return `<p>Error generating summary: ${error.message}</p>`;
  }
}

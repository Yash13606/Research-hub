import { GoogleGenerativeAI } from "@google/generative-ai";
import axios from "axios";
import { XMLParser } from "fast-xml-parser";

// Initialize the Gemini API with your API key
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

// Check if API key is available
if (!process.env.GEMINI_API_KEY) {
  console.warn("Warning: GEMINI_API_KEY is not set in environment variables");
}

// Fetch paper details for summarization
async function fetchPaperDetails(paperId: string): Promise<{
  title: string;
  abstract: string;
  fullText?: string;
}> {
  // In a real implementation, you would fetch this from your database
  // or from the appropriate API (arXiv, PubMed, Semantic Scholar)
  
  try {
    // Try first with arXiv API
    if (paperId.includes('.')) {
      try {
        const response = await axios.get(`http://export.arxiv.org/api/query?id_list=${paperId}`);
        const parser = new XMLParser({
          ignoreAttributes: false,
          attributeNamePrefix: "_",
        });
        const result = parser.parse(response.data);
        
        if (result.feed && result.feed.entry) {
          const entry = result.feed.entry;
          return {
            title: entry.title || "",
            abstract: entry.summary || "",
          };
        }
      } catch (error) {
        console.log("Error fetching from arXiv:", error);
        // Continue to next API
      }
    }
    
    // Try with PubMed
    if (!isNaN(Number(paperId))) {
      try {
        const response = await axios.get(`https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${paperId}&retmode=xml`);
        const parser = new XMLParser({
          ignoreAttributes: false,
          attributeNamePrefix: "_",
        });
        const result = parser.parse(response.data);
        
        if (result.PubmedArticleSet && result.PubmedArticleSet.PubmedArticle) {
          const article = result.PubmedArticleSet.PubmedArticle.MedlineCitation.Article;
          return {
            title: article.ArticleTitle || "",
            abstract: article.Abstract?.AbstractText || "",
          };
        }
      } catch (error) {
        console.log("Error fetching from PubMed:", error);
        // Continue to next API
      }
    }
    
    // Try with Semantic Scholar
    try {
      const response = await axios.get(`https://api.semanticscholar.org/graph/v1/paper/${paperId}?fields=title,abstract`);
      return {
        title: response.data.title || "",
        abstract: response.data.abstract || "",
      };
    } catch (error) {
      console.log("Error fetching from Semantic Scholar:", error);
      // Fall through to default return
    }
    
    // If all APIs failed, return default
    return {
      title: "Unknown paper",
      abstract: "No abstract available",
    };
    
  } catch (error: any) {
    console.error("Error fetching paper details:", error);
    return {
      title: "Unknown paper",
      abstract: "No abstract available",
    };
  }
}

export async function generateSummary(
  paperId: string,
  length: string = "short"
): Promise<string> {
  try {
    // Validate API key is available
    if (!process.env.GEMINI_API_KEY) {
      console.error("GEMINI_API_KEY is not set");
      return `<p>Error generating summary: API key not configured. Please contact the administrator.</p>`;
    }
    
    // Get the paper details
    const paperDetails = await fetchPaperDetails(paperId);
    
    // If we couldn't get any details, return an error message
    if (!paperDetails.title && !paperDetails.abstract) {
      return "<p>Could not find paper details to generate a summary.</p>";
    }
    
    // Determine the word count based on the summary length
    let wordCount: number;
    let detailLevel: string;
    
    switch (length) {
      case "medium":
        wordCount = 250;
        detailLevel = "moderate";
        break;
      case "detailed":
        wordCount = 500;
        detailLevel = "in-depth";
        break;
      case "short":
      default:
        wordCount = 100;
        detailLevel = "brief";
        break;
    }
    
    // Create the prompt for Gemini
    const prompt = `
      You are a scientific research assistant specializing in creating concise summaries of research papers.
      
      Please create a ${detailLevel} HTML-formatted summary of the following research paper. 
      The summary should be approximately ${wordCount} words and highlight the key points, methodology, results, and significance of the paper.
      
      Paper Title: ${paperDetails.title}
      Paper Abstract: ${paperDetails.abstract}
      ${paperDetails.fullText ? `Paper Full Text: ${paperDetails.fullText}` : ""}
      
      Format the summary with HTML tags:
      - Use <h5> tags for section headers like "Key Points", "Methodology", "Results", "Significance"
      - Use <ul> and <li> for listing key points
      - Use <p> for paragraphs
      
      The summary should be well-structured, informative, and highlight the most important aspects of the research.
    `;
    
    // Get the Gemini model - using "gemini-1.5-pro" which is the updated model name
    // Google Gemini has renamed their models, ensure we're using the correct one
    const model = genAI.getGenerativeModel({ 
      model: "gemini-1.5-pro-latest"  // Using latest version
    });
    
    console.log(`Generating summary for paper ID: ${paperId}, length: ${length}`);
    
    // Generate the summary using Gemini
    try {
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Return the generated summary
      return text || "<p>Failed to generate summary.</p>";
    } catch (geminiError: any) {
      console.error("Gemini API Error:", geminiError);
      
      // Check for specific error types
      if (geminiError.message && geminiError.message.includes("404")) {
        return `<p>Error generating summary: The model 'gemini-1.5-pro-latest' was not found. 
        This might be because the model name has changed. Please contact the administrator.</p>`;
      }
      
      if (geminiError.message && geminiError.message.includes("429")) {
        return `<p>Error generating summary: Too many requests to the Gemini API. 
        Please try again later.</p>`;
      }
      
      return `<p>Error generating summary: ${geminiError?.message || "Unknown API error"}</p>`;
    }
  } catch (error: any) {
    console.error("Unexpected error in generateSummary:", error);
    return `<p>Error generating summary: ${error?.message || "Unknown error"}</p>`;
  }
}
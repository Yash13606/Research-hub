import axios from "axios";
import { XMLParser } from "fast-xml-parser";
import { Paper } from "@/lib/types";

export async function fetchPubmedPapers(
  query: string = "",
  categories: string[] = [],
  dateRange: string = "any",
  dateStart?: string,
  dateEnd?: string
): Promise<Paper[]> {
  try {
    // Build the PubMed API query
    let apiQuery = query || "*";
    
    if (categories.length > 0) {
      const categoryMap: Record<string, string> = {
        "Computer Science": "Computer Science[mesh]",
        "Physics": "Physics[mesh]",
        "Mathematics": "Mathematics[mesh]",
        "Biology": "Biology[mesh]",
        "Medicine": "Medicine[mesh]",
      };
      
      const catQueries = categories
        .map(cat => categoryMap[cat])
        .filter(Boolean)
        .join(" OR ");
      
      if (catQueries) {
        apiQuery += ` AND (${catQueries})`;
      }
    }
    
    // Handle date filtering
    let dateFilter = "";
    if (dateRange !== "any") {
      const now = new Date();
      let startDate: Date;
      
      switch (dateRange) {
        case "week":
          startDate = new Date(now.setDate(now.getDate() - 7));
          dateFilter = `${startDate.toISOString().split('T')[0]}:${new Date().toISOString().split('T')[0]}[pdat]`;
          break;
        case "month":
          startDate = new Date(now.setMonth(now.getMonth() - 1));
          dateFilter = `${startDate.toISOString().split('T')[0]}:${new Date().toISOString().split('T')[0]}[pdat]`;
          break;
        case "year":
          startDate = new Date(now.setFullYear(now.getFullYear() - 1));
          dateFilter = `${startDate.toISOString().split('T')[0]}:${new Date().toISOString().split('T')[0]}[pdat]`;
          break;
        case "custom":
          if (dateStart && dateEnd) {
            dateFilter = `${dateStart}:${dateEnd}[pdat]`;
          }
          break;
      }
      
      if (dateFilter) {
        apiQuery += ` AND ${dateFilter}`;
      }
    }
    
    // Build the API URLs for search and fetch
    const baseUrl = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils";
    const searchUrl = `${baseUrl}/esearch.fcgi?db=pubmed&term=${encodeURIComponent(apiQuery)}&retmax=50&sort=date`;
    
    // First get the IDs of matching articles
    const searchResponse = await axios.get(searchUrl);
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: "_",
    });
    const searchResult = parser.parse(searchResponse.data);
    
    // Check if we have results
    if (!searchResult.eSearchResult || !searchResult.eSearchResult.IdList || !searchResult.eSearchResult.IdList.Id) {
      return [];
    }
    
    // Extract IDs
    const ids = Array.isArray(searchResult.eSearchResult.IdList.Id)
      ? searchResult.eSearchResult.IdList.Id
      : [searchResult.eSearchResult.IdList.Id];
    
    if (ids.length === 0) {
      return [];
    }
    
    // Now fetch the full article data
    const fetchUrl = `${baseUrl}/efetch.fcgi?db=pubmed&id=${ids.join(",")}&retmode=xml`;
    const fetchResponse = await axios.get(fetchUrl);
    const fetchResult = parser.parse(fetchResponse.data);
    
    // Extract papers from the response
    const articles = fetchResult.PubmedArticleSet.PubmedArticle || [];
    const papers = Array.isArray(articles) ? articles : [articles];
    
    return papers.map((paper: any) => {
      const article = paper.MedlineCitation.Article;
      
      // Extract authors
      const authorList = article.AuthorList?.Author || [];
      const authors = Array.isArray(authorList)
        ? authorList.map((author: any) => {
            return author.LastName && author.ForeName
              ? `${author.LastName} ${author.ForeName}`
              : author.CollectiveName || "Unknown";
          })
        : [authorList.LastName && authorList.ForeName
            ? `${authorList.LastName} ${authorList.ForeName}`
            : authorList.CollectiveName || "Unknown"];
      
      // Extract publication date
      const pubDate = article.Journal?.JournalIssue?.PubDate;
      let publishDate = new Date();
      if (pubDate) {
        const year = pubDate.Year || "2023";
        const month = pubDate.Month ? monthToNumber(pubDate.Month) : "01";
        const day = pubDate.Day || "01";
        publishDate = new Date(`${year}-${month}-${day}`);
      }
      
      // Extract abstract
      const abstractText = article.Abstract?.AbstractText;
      let abstract = "";
      if (abstractText) {
        if (Array.isArray(abstractText)) {
          abstract = abstractText.map((text: any) => 
            typeof text === 'object' ? text["#text"] || "" : text
          ).join(" ");
        } else {
          abstract = typeof abstractText === 'object' 
            ? abstractText["#text"] || "" 
            : abstractText;
        }
      }
      
      // Extract keywords
      const keywordList = paper.MedlineCitation.KeywordList?.Keyword || [];
      const keywords = Array.isArray(keywordList)
        ? keywordList.map((keyword: any) => 
            typeof keyword === 'object' ? keyword["#text"] || "" : keyword
          ).slice(0, 5)
        : [typeof keywordList === 'object' 
            ? keywordList["#text"] || "" 
            : keywordList];
      
      // Determine category from MeSH headings if available
      const meshHeadings = paper.MedlineCitation.MeshHeadingList?.MeshHeading || [];
      let category = "Medicine"; // Default category for PubMed
      
      if (meshHeadings.length > 0) {
        const headings = Array.isArray(meshHeadings) ? meshHeadings : [meshHeadings];
        const mainHeading = headings[0];
        const headingText = typeof mainHeading === 'object' 
          ? mainHeading.DescriptorName["#text"] || "" 
          : mainHeading;
        
        const categoryMap: Record<string, string> = {
          "Computer": "Computer Science",
          "Physics": "Physics",
          "Mathematics": "Mathematics",
          "Biology": "Biology",
          // Many more mappings could be added here
        };
        
        // Check if the heading matches any of our categories
        for (const [key, value] of Object.entries(categoryMap)) {
          if (headingText.includes(key)) {
            category = value;
            break;
          }
        }
      }
      
      // Get citation count - this is not directly available from PubMed API
      // In a real app, you might query a citation database
      const citations = Math.floor(Math.random() * 100); // Mock value
      
      return {
        id: paper.MedlineCitation.PMID["#text"] || paper.MedlineCitation.PMID,
        title: article.ArticleTitle,
        authors,
        abstract,
        url: `https://pubmed.ncbi.nlm.nih.gov/${paper.MedlineCitation.PMID["#text"] || paper.MedlineCitation.PMID}/`,
        publishDate: publishDate.toISOString(),
        source: "PubMed",
        category,
        citations,
        keywords: keywords.filter(Boolean),
      };
    });
  } catch (error) {
    console.error("Error fetching from PubMed:", error);
    return [];
  }
}

// Helper function to convert month names to numbers
function monthToNumber(month: string): string {
  const months: Record<string, string> = {
    "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04",
    "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
    "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12",
    "January": "01", "February": "02", "March": "03", "April": "04",
    "June": "06", "July": "07", "August": "08", "September": "09",
    "October": "10", "November": "11", "December": "12"
  };
  
  return months[month] || "01";
}

import axios from "axios";
import { Paper } from "@/lib/types";

// Semantic Scholar API key should come from environment variables
const API_KEY = process.env.SEMANTIC_SCHOLAR_API_KEY || "";

// Rate limiting tracking
let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 3000; // 3 seconds between requests
let isRateLimited = false;
let rateLimitResetTime = 0;

export async function fetchSemanticScholarPapers(
  query: string = "",
  categories: string[] = [],
  dateRange: string = "any",
  dateStart?: string,
  dateEnd?: string
): Promise<Paper[]> {
  try {
    // Check if we're currently rate limited
    const now = Date.now();
    if (isRateLimited && now < rateLimitResetTime) {
      console.log(`Semantic Scholar API is rate limited. Skipping request until ${new Date(rateLimitResetTime).toISOString()}`);
      return [];
    }
    
    // Respect rate limiting by enforcing minimum time between requests
    const timeSinceLastRequest = now - lastRequestTime;
    if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
      const waitTime = MIN_REQUEST_INTERVAL - timeSinceLastRequest;
      console.log(`Waiting ${waitTime}ms before making Semantic Scholar API request...`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    // Update last request time
    lastRequestTime = Date.now();
    
    // Build the Semantic Scholar API query
    const baseUrl = "https://api.semanticscholar.org/graph/v1/paper/search";
    
    // Create query parameters
    const params = new URLSearchParams();
    params.append("query", query || "");
    params.append("limit", "20"); // Reduced from 50 to minimize rate limiting issues
    params.append("fields", "paperId,title,authors,abstract,url,venue,year,citationCount,fieldsOfStudy");
    
    // Handle year filtering based on dateRange
    if (dateRange !== "any") {
      const currentYear = new Date().getFullYear();
      let startYear: number;
      
      switch (dateRange) {
        case "week":
        case "month":
          // For week/month, we'll just use the current year as Semantic Scholar API doesn't support finer granularity
          startYear = currentYear;
          params.append("year", startYear.toString());
          break;
        case "year":
          startYear = currentYear - 1;
          params.append("year", `${startYear}-${currentYear}`);
          break;
        case "custom":
          if (dateStart && dateEnd) {
            const startYear = new Date(dateStart).getFullYear();
            const endYear = new Date(dateEnd).getFullYear();
            params.append("year", `${startYear}-${endYear}`);
          }
          break;
      }
    }
    
    // Build the API URL
    const url = `${baseUrl}?${params.toString()}`;
    
    // Make the API request with timeout
    const response = await axios.get(url, {
      headers: API_KEY ? { "x-api-key": API_KEY } : {},
      timeout: 10000 // 10 second timeout
    });
    
    // Reset rate limited status if we successfully got a response
    isRateLimited = false;
    
    // Extract papers from the response
    const papers = response.data.data || [];
    
    // Filter by category if specified
    let filteredPapers = papers;
    if (categories.length > 0) {
      filteredPapers = papers.filter((paper: any) => {
        if (!paper.fieldsOfStudy) return false;
        
        // Map our categories to Semantic Scholar fields of study
        const categoryMap: Record<string, string[]> = {
          "Computer Science": ["Computer Science", "Artificial Intelligence", "Machine Learning"],
          "Physics": ["Physics", "Quantum Physics", "Astrophysics"],
          "Mathematics": ["Mathematics", "Statistics", "Algebra"],
          "Biology": ["Biology", "Molecular Biology", "Bioinformatics"],
          "Medicine": ["Medicine", "Medical", "Health Sciences"],
        };
        
        // Check if any of the paper's fields of study match our categories
        return categories.some(category => 
          categoryMap[category]?.some(field => 
            paper.fieldsOfStudy.includes(field)
          )
        );
      });
    }
    
    // Map to our Paper interface
    return filteredPapers.map((paper: any) => {
      // Determine the best category
      let category = "Other";
      if (paper.fieldsOfStudy && paper.fieldsOfStudy.length > 0) {
        const fieldToCategory: Record<string, string> = {
          "Computer Science": "Computer Science",
          "Artificial Intelligence": "Computer Science",
          "Machine Learning": "Computer Science",
          "Physics": "Physics",
          "Quantum Physics": "Physics",
          "Astrophysics": "Physics",
          "Mathematics": "Mathematics",
          "Statistics": "Mathematics",
          "Algebra": "Mathematics",
          "Biology": "Biology",
          "Molecular Biology": "Biology",
          "Bioinformatics": "Biology",
          "Medicine": "Medicine",
          "Medical": "Medicine",
          "Health Sciences": "Medicine",
        };
        
        // Use the first matching field
        for (const field of paper.fieldsOfStudy) {
          if (fieldToCategory[field]) {
            category = fieldToCategory[field];
            break;
          }
        }
      }
      
      // Format the publication date
      const publishDate = paper.year 
        ? new Date(`${paper.year}-01-01`).toISOString()
        : new Date().toISOString();
      
      // Extract keywords from fields of study
      const keywords = paper.fieldsOfStudy 
        ? paper.fieldsOfStudy.slice(0, 5)
        : [];
      
      return {
        id: paper.paperId,
        title: paper.title || "Untitled",
        authors: paper.authors?.map((author: any) => author.name) || [],
        abstract: paper.abstract || "No abstract available",
        url: paper.url || `https://www.semanticscholar.org/paper/${paper.paperId}`,
        publishDate,
        source: "Semantic Scholar",
        category,
        citations: paper.citationCount || 0,
        keywords,
      };
    });
  } catch (error: any) {
    // Handle rate limiting errors specifically
    if (error.response && error.response.status === 429) {
      console.warn("Semantic Scholar API rate limit reached");
      
      // Set rate limited flag and reset time
      isRateLimited = true;
      // Default to 1 minute if no Retry-After header
      const retryAfter = parseInt(error.response.headers['retry-after'] || '60', 10);
      rateLimitResetTime = Date.now() + (retryAfter * 1000);
      
      console.log(`Rate limit will reset at ${new Date(rateLimitResetTime).toISOString()}`);
    } else {
      console.error("Error fetching from Semantic Scholar:", error.message);
    }
    return [];
  }
}

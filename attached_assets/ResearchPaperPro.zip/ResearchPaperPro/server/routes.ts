import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { fetchArxivPapers } from "./services/arxiv";
import { fetchPubmedPapers } from "./services/pubmed";
import { fetchSemanticScholarPapers } from "./services/semanticScholar";
import { generateSummary } from "./services/gemini";
import { Paper } from "@/lib/types";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for fetching papers
  app.get("/api/papers", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const sortBy = (req.query.sortBy as string) || "date";
      const query = req.query.q as string || "";
      const sources = req.query.sources ? (req.query.sources as string).split(",") : ["arXiv", "PubMed", "Semantic Scholar"];
      const categories = req.query.categories ? (req.query.categories as string).split(",") : [];
      const dateRange = req.query.dateRange as string || "any";
      const dateStart = req.query.dateStart as string;
      const dateEnd = req.query.dateEnd as string;

      // Fetch papers from multiple sources
      const paperPromises = [];
      
      if (sources.includes("arXiv")) {
        paperPromises.push(fetchArxivPapers(query, categories, dateRange, dateStart, dateEnd));
      }
      
      if (sources.includes("PubMed")) {
        paperPromises.push(fetchPubmedPapers(query, categories, dateRange, dateStart, dateEnd));
      }
      
      if (sources.includes("Semantic Scholar")) {
        paperPromises.push(fetchSemanticScholarPapers(query, categories, dateRange, dateStart, dateEnd));
      }

      const paperResults = await Promise.allSettled(paperPromises);
      
      // Combine results from successful fetches
      let allPapers: any[] = [];
      
      for (const result of paperResults) {
        if (result.status === "fulfilled") {
          allPapers = [...allPapers, ...result.value];
        }
      }

      // Apply sorting
      if (sortBy === "date") {
        allPapers.sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime());
      } else if (sortBy === "citations") {
        allPapers.sort((a, b) => (b.citations || 0) - (a.citations || 0));
      }
      // "relevance" sorting is assumed to be done by the API services themselves

      // Paginate results
      const itemsPerPage = 10;
      const totalPages = Math.ceil(allPapers.length / itemsPerPage);
      const startIndex = (page - 1) * itemsPerPage;
      const paginatedPapers = allPapers.slice(startIndex, startIndex + itemsPerPage);

      res.json({
        papers: paginatedPapers,
        totalPages,
      });
    } catch (error) {
      console.error("Error fetching papers:", error);
      res.status(500).json({ error: "Failed to fetch papers" });
    }
  });

  // API route for getting paper summary
  app.get("/api/papers/:paperId/summary", async (req, res) => {
    try {
      const paperId = req.params.paperId;
      const length = req.query.length as string || "short";
      
      // Check if we have a cached summary
      // This would be handled by a database in a real app
      // For now, we'll generate a new summary each time
      
      // For a real implementation, validate that paperId exists first

      const summary = await generateSummary(paperId, length);
      
      res.json(summary);
    } catch (error) {
      console.error("Error generating summary:", error);
      res.status(500).json({ error: "Failed to generate summary" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

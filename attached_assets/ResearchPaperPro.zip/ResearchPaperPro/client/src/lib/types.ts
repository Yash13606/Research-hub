export interface Paper {
  id: string;
  title: string;
  authors: string[];
  abstract: string;
  url: string;
  publishDate: string;
  source: string;
  category: string;
  citations?: number;
  keywords?: string[];
}

export interface Summary {
  id: string;
  paperId: string;
  short: string;
  medium: string;
  detailed: string;
  createdAt: string;
}

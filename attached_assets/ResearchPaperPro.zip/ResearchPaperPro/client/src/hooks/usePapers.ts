import { useQuery } from "@tanstack/react-query";
import { Paper } from "@/lib/types";

interface UsePapersParams {
  page: number;
  sortBy: string;
  searchTerm?: string;
  sources?: string[];
  categories?: string[];
  dateRange?: string;
  dateStart?: string;
  dateEnd?: string;
}

export function usePapers({
  page,
  sortBy,
  searchTerm,
  sources,
  categories,
  dateRange,
  dateStart,
  dateEnd,
}: UsePapersParams) {
  const queryParams = new URLSearchParams();
  
  queryParams.append("page", page.toString());
  queryParams.append("sortBy", sortBy);
  
  if (searchTerm) queryParams.append("q", searchTerm);
  if (sources?.length) queryParams.append("sources", sources.join(","));
  if (categories?.length) queryParams.append("categories", categories.join(","));
  if (dateRange && dateRange !== "any") queryParams.append("dateRange", dateRange);
  if (dateStart) queryParams.append("dateStart", dateStart);
  if (dateEnd) queryParams.append("dateEnd", dateEnd);
  
  const queryString = queryParams.toString();

  const { data, isLoading, error } = useQuery<{
    papers: Paper[];
    totalPages: number;
  }>({
    queryKey: [`/api/papers?${queryString}`],
    keepPreviousData: true,
  });

  return {
    papers: data?.papers || [],
    totalPages: data?.totalPages || 1,
    isLoading,
    error,
  };
}

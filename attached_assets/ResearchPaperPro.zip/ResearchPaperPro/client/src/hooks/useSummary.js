import { useQuery } from "@tanstack/react-query";

export function useSummary(
  paperId,
  length = "short",
  enabled = true
) {
  const { data, isLoading, error, isError } = useQuery({
    queryKey: [`/api/papers/${paperId}/summary`, length],
    enabled: enabled && !!paperId,
  });

  return {
    summary: data,
    isLoading,
    isError,
    error,
  };
}
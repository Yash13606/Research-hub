import { useQuery } from "@tanstack/react-query";

export function useSummary(
  paperId?: string,
  length: "short" | "medium" | "detailed" = "short",
  enabled: boolean = true
) {
  const { data, isLoading, error, isError } = useQuery<string>({
    queryKey: [`/api/papers/${paperId}/summary`, length],
    enabled: enabled && !!paperId,
  });

  return {
    summary: data,
    isLoading,
    isError,
    error,
  };
}

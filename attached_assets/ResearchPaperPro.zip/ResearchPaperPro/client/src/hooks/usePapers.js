import { useQuery } from "@tanstack/react-query";

export function usePapers({
  page,
  sortBy,
  searchTerm,
  sources,
  categories,
  dateRange,
  dateStart,
  dateEnd,
}) {
  const queryParams = new URLSearchParams();
  
  queryParams.append("page", page.toString());
  queryParams.append("sortBy", sortBy);
  
  if (searchTerm) queryParams.append("q", searchTerm);
  if (sources?.length) queryParams.append("sources", sources.join(","));
  if (categories?.length) queryParams.append("categories", categories.join(","));
  if (dateRange && dateRange !== "any") queryParams.append("dateRange", dateRange);
  if (dateStart) queryParams.append("dateStart", dateStart);
  if (dateEnd) queryParams.append("dateEnd", dateEnd);
  
  const queryString = queryParams.toString();

  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/papers?${queryString}`],
    keepPreviousData: true,
  });

  return {
    papers: data?.papers || [],
    totalPages: data?.totalPages || 1,
    isLoading,
    error,
  };
}
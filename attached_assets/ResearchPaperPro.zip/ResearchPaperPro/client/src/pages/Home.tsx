import { useState, useCallback } from "react";
import { SidebarFilters } from "@/components/SidebarFilters";
import { ActiveFilters } from "@/components/ActiveFilters";
import { PaperCard } from "@/components/PaperCard";
import { SummaryModal } from "@/components/SummaryModal";
import { LoadingSkeleton } from "@/components/LoadingSkeleton";
import { Pagination } from "@/components/Pagination";
import { usePapers } from "@/hooks/usePapers";
import { Paper } from "@/lib/types";

interface ActiveFilter {
  type: string;
  value: string;
}

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("date");
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState<{
    sources: string[];
    categories: string[];
    dateRange: string;
    customDateStart?: string;
    customDateEnd?: string;
  }>({
    sources: ["arXiv", "PubMed", "Semantic Scholar"],
    categories: [],
    dateRange: "any",
  });
  
  const [activeFilters, setActiveFilters] = useState<ActiveFilter[]>([]);
  const [selectedPaper, setSelectedPaper] = useState<Paper | null>(null);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);

  const { papers, isLoading, totalPages } = usePapers({
    page: currentPage,
    sortBy,
    searchTerm,
    sources: filters.sources,
    categories: filters.categories,
    dateRange: filters.dateRange,
    dateStart: filters.customDateStart,
    dateEnd: filters.customDateEnd,
  });

  // Use useCallback to prevent recreating this function on every render
  const handleFilterChange = useCallback((newFilters: {
    sources: string[];
    categories: string[];
    dateRange: string;
    customDateStart?: string;
    customDateEnd?: string;
  }) => {
    setFilters(newFilters);
    
    // Update active filters for display
    const updatedActiveFilters: ActiveFilter[] = [];
    
    newFilters.categories.forEach(category => {
      updatedActiveFilters.push({ type: 'category', value: category });
    });
    
    if (newFilters.dateRange !== 'any') {
      let dateFilterValue = '';
      switch (newFilters.dateRange) {
        case 'week':
          dateFilterValue = 'Last 7 days';
          break;
        case 'month':
          dateFilterValue = 'Last 30 days';
          break;
        case 'year':
          dateFilterValue = 'Last year';
          break;
        case 'custom':
          if (newFilters.customDateStart && newFilters.customDateEnd) {
            dateFilterValue = `${newFilters.customDateStart} to ${newFilters.customDateEnd}`;
          }
          break;
      }
      if (dateFilterValue) {
        updatedActiveFilters.push({ type: 'date', value: dateFilterValue });
      }
    }
    
    setActiveFilters(updatedActiveFilters);
    setCurrentPage(1); // Reset to first page when filters change
  }, []);

  const handleRemoveFilter = (filter: ActiveFilter) => {
    if (filter.type === 'category') {
      setFilters({
        ...filters,
        categories: filters.categories.filter(c => c !== filter.value)
      });
    } else if (filter.type === 'date') {
      setFilters({
        ...filters,
        dateRange: 'any',
        customDateStart: undefined,
        customDateEnd: undefined
      });
    }
    
    setActiveFilters(activeFilters.filter(f => !(f.type === filter.type && f.value === filter.value)));
  };

  const handleViewSummary = (paper: Paper) => {
    setSelectedPaper(paper);
    setIsSummaryModalOpen(true);
  };

  const handleCloseSummary = () => {
    setIsSummaryModalOpen(false);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
    setCurrentPage(1); // Reset to first page when sort changes
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex flex-col md:flex-row gap-6">
        <SidebarFilters onFilterChange={handleFilterChange} />
        
        <div className="flex-1">
          <ActiveFilters filters={activeFilters} onRemoveFilter={handleRemoveFilter} />
          
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-gray-800">Latest Research Papers</h2>
            <div className="flex items-center">
              <label htmlFor="sort-by" className="text-sm text-gray-600 mr-2">Sort by:</label>
              <select 
                id="sort-by" 
                className="text-sm border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                value={sortBy}
                onChange={handleSortChange}
              >
                <option value="relevance">Relevance</option>
                <option value="date">Publication Date</option>
                <option value="citations">Citation Count</option>
              </select>
            </div>
          </div>
          
          <div className="space-y-6">
            {isLoading ? (
              <LoadingSkeleton />
            ) : papers && papers.length > 0 ? (
              papers.map((paper: Paper) => (
                <PaperCard
                  key={paper.id}
                  paper={paper}
                  onViewSummary={handleViewSummary}
                />
              ))
            ) : (
              <div className="bg-white rounded-lg shadow-md p-6 text-center">
                <p className="text-gray-700">No papers found matching your criteria. Try adjusting your filters.</p>
              </div>
            )}
          </div>
          
          {papers && papers.length > 0 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />
          )}
        </div>
      </div>
      
      <SummaryModal
        paper={selectedPaper}
        isOpen={isSummaryModalOpen}
        onClose={handleCloseSummary}
      />
    </main>
  );
}

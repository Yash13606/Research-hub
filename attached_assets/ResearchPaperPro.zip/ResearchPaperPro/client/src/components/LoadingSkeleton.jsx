import { Skeleton } from "@/components/ui/skeleton";

export function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      {Array(3).fill(0).map((_, index) => (
        <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100 p-5" key={index}>
          <div className="flex justify-between items-start mb-3">
            <Skeleton className="h-6 w-16 rounded" />
            <div className="flex space-x-2">
              <Skeleton className="h-6 w-6 rounded" />
              <Skeleton className="h-6 w-6 rounded" />
            </div>
          </div>
          <Skeleton className="h-7 w-3/4 rounded mb-2" />
          <Skeleton className="h-5 w-1/2 rounded mb-3" />
          <div className="flex space-x-2 mb-4">
            <Skeleton className="h-4 w-32 rounded" />
            <Skeleton className="h-4 w-40 rounded" />
          </div>
          <div className="space-y-2 mb-4">
            <Skeleton className="h-4 w-full rounded" />
            <Skeleton className="h-4 w-full rounded" />
            <Skeleton className="h-4 w-2/3 rounded" />
          </div>
          <div className="flex space-x-2 mb-4">
            <Skeleton className="h-6 w-20 rounded-full" />
            <Skeleton className="h-6 w-20 rounded-full" />
          </div>
          <div className="flex space-x-2">
            <Skeleton className="h-10 w-32 rounded" />
            <Skeleton className="h-10 w-32 rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}
import { X } from "lucide-react";

interface ActiveFilter {
  type: string;
  value: string;
}

interface ActiveFiltersProps {
  filters: ActiveFilter[];
  onRemoveFilter: (filter: ActiveFilter) => void;
}

export function ActiveFilters({ filters, onRemoveFilter }: ActiveFiltersProps) {
  if (filters.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-2 mb-4">
      <span className="text-gray-700">Active filters:</span>
      {filters.map((filter, index) => (
        <span 
          key={index} 
          className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm flex items-center"
        >
          {filter.value}
          <button 
            className="ml-1 text-gray-500 hover:text-gray-700"
            onClick={() => onRemoveFilter(filter)}
            aria-label={`Remove ${filter.value} filter`}
          >
            <X className="h-3 w-3" />
          </button>
        </span>
      ))}
    </div>
  );
}

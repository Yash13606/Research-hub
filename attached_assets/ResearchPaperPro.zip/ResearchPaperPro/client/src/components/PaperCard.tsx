import { useState } from "react";
import { Bookmark, Share, ExternalLink, BookOpen, Calendar, Folder, Quote } from "lucide-react";
import { Paper } from "@/lib/types";
import { toast } from "sonner";

interface PaperCardProps {
  paper: Paper;
  onViewSummary: (paper: Paper) => void;
}

export function PaperCard({ paper, onViewSummary }: PaperCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(false);

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsBookmarked(!isBookmarked);
    toast.success(
      isBookmarked 
        ? "Paper removed from bookmarks" 
        : "Paper added to bookmarks"
    );
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator.share({
        title: paper.title,
        text: `Check out this research paper: ${paper.title}`,
        url: paper.url,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(paper.url);
      toast.success("Link copied to clipboard");
    }
  };

  const getSourceBackgroundColor = (source: string) => {
    switch (source.toLowerCase()) {
      case 'arxiv':
        return 'bg-cyan-600';
      case 'pubmed':
        return 'bg-blue-600';
      case 'semantic scholar':
        return 'bg-purple-600';
      default:
        return 'bg-primary';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-shadow">
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <span className={`${getSourceBackgroundColor(paper.source)} text-white text-xs px-2 py-1 rounded`}>
            {paper.source}
          </span>
          <div className="flex space-x-2">
            <button
              onClick={handleBookmark}
              className={`${isBookmarked ? "text-primary" : "text-gray-400"} hover:text-gray-600`}
              aria-label={isBookmarked ? "Remove bookmark" : "Add bookmark"}
            >
              <Bookmark className="h-5 w-5" />
            </button>
            <button
              onClick={handleShare}
              className="text-gray-400 hover:text-gray-600"
              aria-label="Share paper"
            >
              <Share className="h-5 w-5" />
            </button>
          </div>
        </div>

        <h3 className="font-serif text-lg font-bold text-gray-900 mb-2">
          {typeof paper.title === 'string' ? paper.title : 'Untitled Paper'}
        </h3>

        <div className="mb-3 text-sm text-gray-600">
          {paper.authors.join(", ")}
        </div>

        <div className="flex flex-wrap text-xs text-gray-500 mb-4 gap-3">
          <span className="flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{new Date(paper.publishDate).toLocaleDateString()}</span>
          </span>
          <span className="flex items-center">
            <Folder className="h-4 w-4 mr-1" />
            <span>{paper.category}</span>
          </span>
          {paper.citations && (
            <span className="flex items-center">
              <Quote className="h-4 w-4 mr-1" />
              <span>{paper.citations.toLocaleString()} citations</span>
            </span>
          )}
        </div>

        <p className="text-gray-700 mb-4 line-clamp-3">{paper.abstract}</p>

        {paper.keywords && paper.keywords.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {paper.keywords.map((keyword, index) => (
              <span key={index} className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full">
                {keyword}
              </span>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          <button
            className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors flex items-center"
            onClick={() => onViewSummary(paper)}
          >
            <BookOpen className="h-4 w-4 mr-1" />
            View Summary
          </button>
          <a
            href={paper.url}
            className="bg-white text-primary border border-primary px-4 py-2 rounded-md hover:bg-primary/10 transition-colors flex items-center"
            target="_blank"
            rel="noopener noreferrer"
          >
            <ExternalLink className="h-4 w-4 mr-1" />
            View Original
          </a>
        </div>
      </div>
    </div>
  );
}

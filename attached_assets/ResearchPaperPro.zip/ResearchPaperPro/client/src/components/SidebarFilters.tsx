import { useState } from "react";

interface SidebarFiltersProps {
  onFilterChange: (filters: {
    sources: string[];
    categories: string[];
    dateRange: string;
    customDateStart?: string;
    customDateEnd?: string;
  }) => void;
}

export function SidebarFilters({ onFilterChange }: SidebarFiltersProps) {
  const [sources, setSources] = useState<string[]>(["arXiv", "PubMed", "Semantic Scholar"]);
  const [categories, setCategories] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<string>("any");
  const [customDateStart, setCustomDateStart] = useState<string>("");
  const [customDateEnd, setCustomDateEnd] = useState<string>("");
  
  const allSources = ["arXiv", "PubMed", "Semantic Scholar"];
  const allCategories = [
    "Computer Science",
    "Physics",
    "Biology",
    "Mathematics",
    "Medicine",
  ];

  const handleSourceChange = (source: string, checked: boolean) => {
    if (checked) {
      setSources(prev => [...prev, source]);
    } else {
      setSources(prev => prev.filter((s) => s !== source));
    }
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setCategories(prev => [...prev, category]);
    } else {
      setCategories(prev => prev.filter((c) => c !== category));
    }
  };

  const handleApplyFilters = () => {
    onFilterChange({
      sources,
      categories,
      dateRange,
      customDateStart: dateRange === "custom" ? customDateStart : undefined,
      customDateEnd: dateRange === "custom" ? customDateEnd : undefined,
    });
  };

  const handleResetFilters = () => {
    setSources(["arXiv", "PubMed", "Semantic Scholar"]);
    setCategories([]);
    setDateRange("any");
    setCustomDateStart("");
    setCustomDateEnd("");
    
    // Apply the reset filters
    onFilterChange({
      sources: ["arXiv", "PubMed", "Semantic Scholar"],
      categories: [],
      dateRange: "any"
    });
  };

  return (
    <aside className="w-full md:w-64 lg:w-72 flex-shrink-0 md:sticky md:top-4 h-fit">
      <div className="bg-white rounded-lg shadow-md p-4 mb-4">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">Sources</h2>
        <div className="space-y-3">
          {allSources.map((source) => (
            <div className="flex items-center" key={source}>
              <input
                type="checkbox"
                id={`source-${source.toLowerCase().replace(/\s/g, "-")}`}
                className="rounded text-primary focus:ring-primary"
                checked={sources.includes(source)}
                onChange={(e) => handleSourceChange(source, e.target.checked)}
              />
              <label
                htmlFor={`source-${source.toLowerCase().replace(/\s/g, "-")}`}
                className="ml-2 text-gray-700"
              >
                {source}
              </label>
            </div>
          ))}
        </div>

        <h2 className="text-lg font-semibold text-gray-800 mt-6 mb-4">Categories</h2>
        <div className="space-y-3">
          {allCategories.map((category) => (
            <div className="flex items-center" key={category}>
              <input
                type="checkbox"
                id={`cat-${category.toLowerCase().replace(/\s/g, "-")}`}
                className="rounded text-primary focus:ring-primary"
                checked={categories.includes(category)}
                onChange={(e) => handleCategoryChange(category, e.target.checked)}
              />
              <label
                htmlFor={`cat-${category.toLowerCase().replace(/\s/g, "-")}`}
                className="ml-2 text-gray-700"
              >
                {category}
              </label>
            </div>
          ))}
        </div>

        <h2 className="text-lg font-semibold text-gray-800 mt-6 mb-4">Publication Date</h2>
        <div className="space-y-3">
          <div className="flex items-center">
            <input
              type="radio"
              name="pub-date"
              id="date-any"
              className="text-primary focus:ring-primary"
              checked={dateRange === "any"}
              onChange={() => setDateRange("any")}
            />
            <label htmlFor="date-any" className="ml-2 text-gray-700">
              Any time
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="radio"
              name="pub-date"
              id="date-week"
              className="text-primary focus:ring-primary"
              checked={dateRange === "week"}
              onChange={() => setDateRange("week")}
            />
            <label htmlFor="date-week" className="ml-2 text-gray-700">
              Past week
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="radio"
              name="pub-date"
              id="date-month"
              className="text-primary focus:ring-primary"
              checked={dateRange === "month"}
              onChange={() => setDateRange("month")}
            />
            <label htmlFor="date-month" className="ml-2 text-gray-700">
              Past month
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="radio"
              name="pub-date"
              id="date-year"
              className="text-primary focus:ring-primary"
              checked={dateRange === "year"}
              onChange={() => setDateRange("year")}
            />
            <label htmlFor="date-year" className="ml-2 text-gray-700">
              Past year
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="radio"
              name="pub-date"
              id="date-custom"
              className="text-primary focus:ring-primary"
              checked={dateRange === "custom"}
              onChange={() => setDateRange("custom")}
            />
            <label htmlFor="date-custom" className="ml-2 text-gray-700">
              Custom range
            </label>
          </div>

          {dateRange === "custom" && (
            <div className="mt-2">
              <label className="block text-sm text-gray-700 mb-1">Custom date range</label>
              <div className="flex items-center space-x-2">
                <input
                  type="date"
                  className="rounded border border-gray-300 text-sm px-2 py-1 w-full focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                  value={customDateStart}
                  onChange={(e) => setCustomDateStart(e.target.value)}
                />
                <span>to</span>
                <input
                  type="date"
                  className="rounded border border-gray-300 text-sm px-2 py-1 w-full focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                  value={customDateEnd}
                  onChange={(e) => setCustomDateEnd(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-gray-200">
          <button 
            className="w-full bg-primary text-white py-2 rounded-md hover:bg-primary/90 transition-colors"
            onClick={handleApplyFilters}
          >
            Apply Filters
          </button>
          <button 
            className="w-full text-gray-600 py-2 mt-2 rounded-md hover:bg-gray-100 transition-colors"
            onClick={handleResetFilters}
          >
            Reset
          </button>
        </div>
      </div>
    </aside>
  );
}

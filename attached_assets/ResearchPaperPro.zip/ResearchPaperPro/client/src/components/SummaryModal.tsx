import { useState, useEffect } from "react";
import { X, ExternalLink, Copy, Save, AlertCircle, RefreshCw } from "lucide-react";
import { Paper } from "@/lib/types";
import { useSummary } from "@/hooks/useSummary";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";

interface SummaryModalProps {
  paper: Paper | null;
  isOpen: boolean;
  onClose: () => void;
}

type SummaryLength = "short" | "medium" | "detailed";

export function SummaryModal({ paper, isOpen, onClose }: SummaryModalProps) {
  const [summaryLength, setSummaryLength] = useState<SummaryLength>("short");
  const { summary, isLoading, isError } = useSummary(paper?.id, summaryLength, isOpen && !!paper);
  const queryClient = useQueryClient();
  
  // Reset summary length when paper changes
  useEffect(() => {
    if (paper) {
      setSummaryLength("short");
    }
  }, [paper?.id]);

  const handleCopy = () => {
    if (summary) {
      // Remove HTML tags when copying to clipboard
      const tempElement = document.createElement('div');
      tempElement.innerHTML = summary;
      const textContent = tempElement.textContent || tempElement.innerText || summary;
      navigator.clipboard.writeText(textContent);
      toast.success("Summary copied to clipboard");
    }
  };

  const handleRetry = () => {
    if (paper?.id) {
      // Invalidate the cache for this summary and retry
      queryClient.invalidateQueries({ 
        queryKey: [`/api/papers/${paper.id}/summary`, summaryLength]
      });
      toast.success("Retrying summary generation...");
    }
  };

  const handleSave = () => {
    // In a real app, this would save to a user's account
    toast.success("Summary saved successfully");
  };
  
  // Check if summary contains an error message
  const hasErrorMessage = summary && summary.includes('Error generating summary');

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center px-6 py-4 border-b border-gray-200">
          <h3 className="text-xl font-bold text-gray-900">Paper Summary</h3>
          <button 
            className="text-gray-500 hover:text-gray-700"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="overflow-y-auto p-6 flex-grow">
          {paper && (
            <>
              <h4 className="font-serif text-lg font-bold text-gray-900 mb-2">{paper.title}</h4>
              <p className="text-sm text-gray-600 mb-4">{paper.authors.join(", ")}</p>
              
              {/* Summary Length Toggle */}
              <div className="flex mb-6">
                <button 
                  className={`flex-1 py-2 text-center border-b-2 ${
                    summaryLength === "short" 
                      ? "border-primary text-primary font-medium" 
                      : "border-gray-200 text-gray-600 hover:text-gray-800"
                  }`}
                  onClick={() => setSummaryLength("short")}
                >
                  Short
                </button>
                <button 
                  className={`flex-1 py-2 text-center border-b-2 ${
                    summaryLength === "medium" 
                      ? "border-primary text-primary font-medium" 
                      : "border-gray-200 text-gray-600 hover:text-gray-800"
                  }`}
                  onClick={() => setSummaryLength("medium")}
                >
                  Medium
                </button>
                <button 
                  className={`flex-1 py-2 text-center border-b-2 ${
                    summaryLength === "detailed" 
                      ? "border-primary text-primary font-medium" 
                      : "border-gray-200 text-gray-600 hover:text-gray-800"
                  }`}
                  onClick={() => setSummaryLength("detailed")}
                >
                  Detailed
                </button>
              </div>
              
              {/* Summary Content */}
              <div className="prose prose-slate max-w-none">
                {isLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-5/6" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-5/6" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                ) : isError || hasErrorMessage ? (
                  <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-4">
                    <div className="flex items-center mb-3">
                      <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                      <h5 className="text-red-700 font-medium">Error Generating Summary</h5>
                    </div>
                    <p className="text-red-600 mb-3">There was an error generating the summary for this paper. This may be due to API limits or an issue with the AI service.</p>
                    <button 
                      onClick={handleRetry}
                      className="inline-flex items-center text-red-700 hover:text-red-800 font-medium"
                    >
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Retry Generation
                    </button>
                  </div>
                ) : (
                  <div dangerouslySetInnerHTML={{ __html: summary || "" }} />
                )}
              </div>
            </>
          )}
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 flex justify-between">
          <a 
            href={paper?.url} 
            className="bg-white text-primary border border-primary px-4 py-2 rounded-md hover:bg-primary/10 transition-colors flex items-center"
            target="_blank"
            rel="noopener noreferrer"
          >
            <ExternalLink className="h-4 w-4 mr-1" />
            View Original Paper
          </a>
          <div>
            {isError || hasErrorMessage ? (
              <button 
                className="bg-red-100 text-red-700 px-4 py-2 rounded-md hover:bg-red-200 transition-colors flex items-center"
                onClick={handleRetry}
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Retry Summary Generation
              </button>
            ) : (
              <>
                <button 
                  className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-200 transition-colors mr-2 flex items-center"
                  onClick={handleCopy}
                  disabled={isLoading}
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Copy Summary
                </button>
                <button 
                  className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary/90 transition-colors flex items-center"
                  onClick={handleSave}
                  disabled={isLoading}
                >
                  <Save className="h-4 w-4 mr-1" />
                  Save Summary
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

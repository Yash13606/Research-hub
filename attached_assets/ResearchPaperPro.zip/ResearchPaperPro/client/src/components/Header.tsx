import { useState } from "react";
import { Link } from "wouter";
import { Search, Settings, BookOpen, Bookmark, UserCircle, SlidersHorizontal } from "lucide-react";

export function Header() {
  const [searchTerm, setSearchTerm] = useState("");
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search logic
    console.log("Searching for:", searchTerm);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <BookOpen className="text-primary mr-2" />
          <Link href="/">
            <span className="text-2xl font-bold text-primary-700 cursor-pointer">ResearchHub</span>
          </Link>
        </div>
        
        <div className="w-full md:w-1/2 lg:w-2/5">
          <form onSubmit={handleSearch} className="relative">
            <input 
              type="text" 
              placeholder="Search papers, authors, topics..." 
              className="w-full rounded-lg border border-gray-300 pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            <button type="button" className="absolute right-3 top-2.5 text-gray-400 hover:text-primary">
              <SlidersHorizontal className="h-5 w-5" />
            </button>
          </form>
        </div>
        
        <div className="hidden md:flex items-center space-x-4">
          <button className="flex items-center text-gray-600 hover:text-primary">
            <Bookmark className="h-4 w-4 mr-1" />
            <span>Saved</span>
          </button>
          <button className="flex items-center text-gray-600 hover:text-primary">
            <Settings className="h-4 w-4 mr-1" />
            <span>Settings</span>
          </button>
          <button className="flex items-center text-gray-600 hover:text-primary">
            <UserCircle className="h-4 w-4 mr-1" />
            <span>Sign In</span>
          </button>
        </div>
      </div>
    </header>
  );
}

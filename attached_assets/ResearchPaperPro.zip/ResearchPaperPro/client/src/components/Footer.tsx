import { Link } from "wouter";
import { Facebook, Twitter, Linkedin, Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-800 text-gray-300 py-8 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">ResearchHub</h3>
            <p className="text-sm">
              A unified platform for discovering, summarizing, and exploring research papers from multiple academic sources.
            </p>
          </div>
          <div>
            <h4 className="text-white text-md font-semibold mb-4">Features</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Paper Search</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">AI Summaries</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">API Documentation</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Save & Organize</span></Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white text-md font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Help Center</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">API Status</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Data Sources</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Privacy Policy</span></Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white text-md font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Contact Us</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Support</span></Link></li>
              <li><Link href="/"><span className="hover:text-white cursor-pointer">Feedback</span></Link></li>
              <li className="flex space-x-4 mt-4">
                <a href="#" className="hover:text-white"><Facebook className="h-5 w-5" /></a>
                <a href="#" className="hover:text-white"><Twitter className="h-5 w-5" /></a>
                <a href="#" className="hover:text-white"><Linkedin className="h-5 w-5" /></a>
                <a href="#" className="hover:text-white"><Github className="h-5 w-5" /></a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-4 text-sm text-center">
          <p>&copy; {new Date().getFullYear()} ResearchHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

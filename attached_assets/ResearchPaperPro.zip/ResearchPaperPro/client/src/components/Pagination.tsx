import { ChevronLeft, ChevronRight } from "lucide-react";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function Pagination({ currentPage, totalPages, onPageChange }: PaginationProps) {
  // Generate page numbers to show
  const getPageNumbers = () => {
    const pages = [];
    const maxPagesToShow = 5;
    
    // Always show first page
    if (currentPage > 3) {
      pages.push(1);
      if (currentPage > 4) {
        pages.push("...");
      }
    }
    
    // Calculate range around current page
    const start = Math.max(1, currentPage - 1);
    const end = Math.min(totalPages, currentPage + maxPagesToShow - pages.length - 1);
    
    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    
    // Show last page if not already included
    if (end < totalPages - 1) {
      pages.push("...");
    }
    if (end < totalPages) {
      pages.push(totalPages);
    }
    
    return pages;
  };

  return (
    <div className="flex justify-center items-center mt-8">
      <div className="flex rounded-md">
        <button
          className="px-3 py-2 border border-gray-300 bg-white text-gray-500 rounded-l-md hover:bg-gray-50 disabled:opacity-50"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        
        {getPageNumbers().map((page, index) => (
          typeof page === 'number' ? (
            <button
              key={index}
              className={`px-4 py-2 border-t border-b border-gray-300 ${
                page === currentPage
                  ? 'bg-primary text-white hover:bg-primary/90'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
              onClick={() => onPageChange(page)}
            >
              {page}
            </button>
          ) : (
            <span key={index} className="px-4 py-2 border-t border-b border-gray-300 bg-white text-gray-700">
              {page}
            </span>
          )
        ))}
        
        <button
          className="px-3 py-2 border border-gray-300 bg-white text-gray-500 rounded-r-md hover:bg-gray-50 disabled:opacity-50"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          aria-label="Next page"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}

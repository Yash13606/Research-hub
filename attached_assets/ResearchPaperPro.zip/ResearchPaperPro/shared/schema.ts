import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Paper table to store paper information
export const papers = pgTable("papers", {
  id: text("id").primaryKey(), // External ID from the source (arXiv, PubMed, etc.)
  title: text("title").notNull(),
  authors: jsonb("authors").notNull().$type<string[]>(), // Array of author names
  abstract: text("abstract").notNull(),
  url: text("url").notNull(),
  publishDate: timestamp("publish_date").notNull(),
  source: text("source").notNull(), // arXiv, PubMed, Semantic Scholar
  category: text("category").notNull(),
  citations: integer("citations"),
  keywords: jsonb("keywords").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Summary table to store generated summaries
export const summaries = pgTable("summaries", {
  id: serial("id").primaryKey(),
  paperId: text("paper_id").notNull().references(() => papers.id),
  short: text("short").notNull(),
  medium: text("medium").notNull(),
  detailed: text("detailed").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User saved papers
export const savedPapers = pgTable("saved_papers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  paperId: text("paper_id").notNull().references(() => papers.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertPaperSchema = createInsertSchema(papers).omit({
  createdAt: true,
});

export const insertSummarySchema = createInsertSchema(summaries).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSavedPaperSchema = createInsertSchema(savedPapers).omit({
  id: true,
  createdAt: true,
});

// Infer types
export type InsertPaper = z.infer<typeof insertPaperSchema>;
export type InsertSummary = z.infer<typeof insertSummarySchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertSavedPaper = z.infer<typeof insertSavedPaperSchema>;

export type Paper = typeof papers.$inferSelect;
export type Summary = typeof summaries.$inferSelect;
export type User = typeof users.$inferSelect;
export type SavedPaper = typeof savedPapers.$inferSelect;
